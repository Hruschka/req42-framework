# Randbedingungen {#section-Randbedingungen}

::: formalpara-title
**Inhalt**
:::

Technologische oder organisatorische Randbedingungen, bzw.
Randbedingungen für den Entwicklungsprozess, wie verpflichtende
Tätigkeiten, vorgeschriebene Dokumente und deren Inhalt, einzuhaltenden
Meilensteine, ...

::: formalpara-title
**Motivation**
:::

Auch solche Randbedingungen sind Anforderungen. Und da sie oft für
mehrere oder sogar alle funktionalen Anforderungen gelten, sind sie
schwer in dem geordneten Product Backlog unterzubringen. Stellen Sie
einfach sicher, dass alle Beteiligten diese Randbedingungen kennen und
bei Bedarf Zugriff dazu haben.

::: formalpara-title
**Notationen/Tools**
:::

Einfache Listen, evtl. nach Kategorien geordnet.

## 7.1 Organisatorische Randbedingungen {#_7_1_organisatorische_randbedingungen}

\* \* \*

## 7.2 Technische Randbedingungen {#_7_2_technische_randbedingungen}

\* \* \*
