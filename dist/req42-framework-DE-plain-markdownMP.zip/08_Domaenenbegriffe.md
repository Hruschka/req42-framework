# Domänenbegriffe {#section-Domaenenbegriffe}

::: formalpara-title
**Inhalt**
:::

Ein Glossar von fachlichen Begriffen mit Definitionen.

::: formalpara-title
**Motivation**
:::

In jedem Epic, Feature oder Story kommen Begriffe aus Ihrer Domäne vor.
Diese Begriffe sollten allen Beteiligten klar sein. Und deshalb ist es
wünschenswert, für ein Projekt oder eine Produktentwicklung ein Glossar
solcher Begriffe zu haben. Stellen Sie sicher, dass alle Beteiligten
eine gemeinsame Sprache sprechen -- und im Zweifelsfall Zugriff auf
vereinbarte Begriffsdefinitionen haben, statt in jedem Meeting wieder
neue Wörter ins Spiel zu bringen.

::: formalpara-title
**Notationen/Tools**
:::

Alphabetisch geordnete Liste von Begriffsdefinitionen

Siehe [Laufzeitsicht](https://docs.arc42.org/section-6/) in der
online-Dokumentation (auf Englisch!).

+-----------------+-----------------------------------------------------+
| Bedeutung       | Erläuterung                                         |
+=================+=====================================================+
| *\<Begriff-1>*  | *\<Erläuterung-1>*                                  |
+-----------------+-----------------------------------------------------+
| *\<Begriff-2>*  | *\<Erläuterung-2>*                                  |
+-----------------+-----------------------------------------------------+
