=================
|req42| Framework
=================

:Date: September 2026

**About req42**

req42, the framework for collecting, documenting and communicating
requirements.

Created and maintained by Dr. Peter Hruschka, Markus Meuten and
contributors.

Template Revision: 2.0.1-EN (based on asciidoc), September 2026

© We acknowledge that this document uses material from the req42
framework, https://req42.de

.. _section-business-goals:

Business Goals
==============

Goal definitions according to PAM:

Goal 1:

Advantage 1:

Metric 1:

Goal 2:

Advantage 2:

Metric 2:

Goal 3:

Advantage 3:

Metric 3:

.. _section-stakeholder:

Stakeholder
===========

+-------------+---------------------------+-------------+-------------+
| Role        | Person                    | Topic       | Influence   |
+=============+===========================+=============+=============+
| *<Role-1>*  | *<Person-1>*              | *<Topic-1>* | *<In        |
|             |                           |             | fluence-1>* |
+-------------+---------------------------+-------------+-------------+
| *<Role-2>*  | *<Person-2>*              | *<Topic-2>* | *<In        |
|             |                           |             | fluence-2>* |
+-------------+---------------------------+-------------+-------------+
|             |                           |             |             |
+-------------+---------------------------+-------------+-------------+

.. _section-scope:

Scope
=====

Insert *<Context diagram>* or *<Context table>* here.

Optional: add table with explanations of interfaces:

+----------+-----------------------------------------------------------+
| I        | Meaning/Explanation                                       |
| nterface |                                                           |
| Name     |                                                           |
+==========+===========================================================+
| *<IF-1>* | *<Meaning-1>*                                             |
+----------+-----------------------------------------------------------+
| *<IF-2>* | *<Meaning-2>*                                             |
+----------+-----------------------------------------------------------+
|          |                                                           |
+----------+-----------------------------------------------------------+

.. _section-product-backlog:

Product Backlog
===============

EPIC 1: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

FEATURE 1.1: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

STORY 1.1.1: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

STORY 1.1.x.:As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

EPIC 2: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

FEATURE 2.1: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

STORY 2.1.1: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

STORY 2.1.2: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

FEATURE 2.2: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

STORY 2.2.1: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

STORY 2.2.2: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

EPIC 3: As *<role>* I want *<functionality>* so that *<advantage>*.
*<optional: Link to models>*.

.. _section-suppporting-models:

Supporting Models
=================

*<Diagram Title 1:>*. *<insert diagram and explanations here >*
*<optional: Link to Epics, Features or Stories>*

*<Diagram Title 2:>*. *<insert diagram and explanations here >*
*<optional: Link to Epics, Features or Stories>*

*<Diagram Title 3:>*. *<insert diagram and explanations here >*
*<optional: Link to Epics, Features or Stories>*

::

   .
   .
   .

*<Diagram Title n:>*. *<insert diagram and explanations here >*
*<optional: Link to Epics, Features or Stories>*

.. _section-quality-requirements:

Quality Requirements
====================

*< quality requirement or scenario 1>* : *<Link to functional
requirements or scope for this quality >*

*< quality requirement or scenario 2>* : *<Link to functional
requirements or scope for this quality >*

*< quality requirement or scenario 3>* : *<Link to functional
requirements or scope for this quality >*

::

   .
   .
   .

*< quality requirement or scenario n>* : *<Link to functional
requirements or scope for this quality >*

.. _section-constraints:

Constraints
===========

.. _`_organizational_constraints`:

Organizational Constraints
--------------------------

-  *<OrgConstraint1>*

-  *<OrgConstraint2>*

-  *<OrgContraint3>*

.. _`_technical_constraints`:

Technical Constraints
---------------------

-  *<TechConstraint1>*

-  *<TechConstraint2>*

-  *<TechContraint3>*

.. _section-domain-terminology:

Domain Terminology
==================

+------------+---------------------------------------------------------+
| Term       | Definition                                              |
+============+=========================================================+
| *<Term-1>* | *<Definition-1>*                                        |
+------------+---------------------------------------------------------+
| *<Term-2>* | *<Definition-2>*                                        |
+------------+---------------------------------------------------------+
|            |                                                         |
+------------+---------------------------------------------------------+

.. _section-assets:

Assets
======

.. _`_budget`:

Budget
------

(possibly structured according to roadmap or intermediate goals, or
divided into personnel budget, material budget, …​)

.. _`_time_framefinal_date`:

Time frame/final date
---------------------

.. _`_team_members`:

Team members
------------

(simple enumeration of team members for small team. Or a link to complex
team structure in section 10).

.. _`_external_resources`:

External resources
------------------

.. _section-teams:

Teams
=====

+-------------+---------------------------+---------------------------+
| Team        | Team Members              | Feature                   |
+=============+===========================+===========================+
| *<Team-1>*  | PO: *<Person-1>*          | *<Feature-A>*             |
+-------------+---------------------------+---------------------------+
|             | *<Team member-2>*         |                           |
+-------------+---------------------------+---------------------------+
|             | *<Team member-3>*         |                           |
+-------------+---------------------------+---------------------------+
|             |                           |                           |
+-------------+---------------------------+---------------------------+
| *<Team-2>*  | PO: *<Person-2>*          | *<Feature-B>*             |
+-------------+---------------------------+---------------------------+
|             | *<Team member-2>*         |                           |
+-------------+---------------------------+---------------------------+
|             |                           |                           |
+-------------+---------------------------+---------------------------+

.. _section-roadmap:

Roadmap
=======

*< Insert your planning here>*

.. _section-risks-assumptions:

Risks & Assumptions
===================

.. _`_risks`:

Risks
-----

+------+----------------------+------+------+-----------------------+
| Id   | Text                 | Pro  | Da   | Possible Measures     |
|      |                      | babi | mage |                       |
|      |                      | lity | Am   |                       |
|      |                      |      | ount |                       |
+======+======================+======+======+=======================+
|      |                      |      |      |                       |
+------+----------------------+------+------+-----------------------+
|      |                      |      |      |                       |
+------+----------------------+------+------+-----------------------+

.. _`_assumptions`:

Assumptions
-----------

+----------+-----------------------------------------------------------+
| Id       | Text                                                      |
+==========+===========================================================+
|          |                                                           |
+----------+-----------------------------------------------------------+
|          |                                                           |
+----------+-----------------------------------------------------------+

.. |req42| image:: images/REQ42-logo.png
