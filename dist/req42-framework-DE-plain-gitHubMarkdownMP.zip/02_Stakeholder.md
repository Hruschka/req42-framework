# Stakeholder

| Rolle         | Person         | Thema         | Einfluss         |
|---------------|----------------|---------------|------------------|
| *\<Rolle-1\>* | *\<Person-1\>* | *\<Thema-1\>* | *\<Einfluss-1\>* |
| *\<Rolle-2\>* | *\<Person-2\>* | *\<Thema-2\>* | *\<Einfluss-2\>* |
