# Teamstruktur

| Team         | Team-Mitglied       | Themen              |
|--------------|---------------------|---------------------|
| *\<Team-1\>* | PO: *\<Name\>*      | *\<Teilprodukt-A\>* |
|              | *\<Team-Member-1\>* |                     |
|              |                     |                     |
| *\<Team-2\>* | PO: *\<Name\>*      | *\<Teilprodukt-B\>* |
|              | *\<Team-Member-1\>* |                     |
|              | *\<Team-Member-2\>* |                     |
|              |                     |                     |
