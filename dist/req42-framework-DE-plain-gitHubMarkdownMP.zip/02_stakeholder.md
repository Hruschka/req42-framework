# Stakeholder

<div class="formalpara-title">

**Inhalt**

</div>

Eine (priorisierte) Liste Ihrer Stakeholder, zusammen Angaben, wo diese
Stakeholder bei der Analysearbeit helfen (oder hindern) können.

<div class="formalpara-title">

**Motivation**

</div>

Stakeholder sind die wichtigsten Quellen für Anforderungen. Deshalb
sollten Sie diese kennen und dokumentieren. Sie müssen wissen, wer davon
Ihnen wobei helfen oder Sie in welcher Form behindern kann. Sie müssen
wissen, wer welchen Einfluss hat – und bei unterschiedlichen Meinungen
müssen Sie vermitteln oder entscheiden.

Ohne explizit identifizierte Stakeholder ist das alles schwierig.

-   Tabellen oder Listen (einfache Form)

-   Evtl. Stakeholder-Map (komplexere Form)

Nachfolgend haben wir als Beispiel eine einfache Stakeholder-Liste
eingefügt.

Die Reihenfolge "Rolle vor Person" ist bewusst gewählt. Diese
Reihenfolge hat sich bewährt da Anforderungen normalerweise immer
Bedarfe aus Sicht einer Rolle darstellen, die Person, welche die Rolle
einnimmt während des Projektes aber durchaus wechseln kann.

Sie können bei Bedarf auch gerne weitere Spalten hinzufügen
(Kontaktdaten, …) – bedenken Sie aber den Aufwand für deren Pflege.

| Rolle        | Person        | Thema        | Einfluss        |
|--------------|---------------|--------------|-----------------|
| *\<Rolle-1>* | *\<Person-1>* | *\<Thema-1>* | *\<Einfluss-1>* |
| *\<Rolle-2>* | *\<Person-2>* | *\<Thema-2>* | *\<Einfluss-2>* |
