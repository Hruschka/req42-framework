# Risiken und Annahmen

## Risiken

| Nr. | Text           | Wahrschein-lichkeit | Schadens-höhe | Evtl. Maßnahmen  |
|-----|----------------|---------------------|---------------|------------------|
| *1* | *\<Risiko-1\>* | *\<%-1\>*           | *\<Höhe-1\>*  | *\<Maßnahme-1\>* |
| *2* | *\<Risiko-2\>* | *\<%-2\>*           | *\<Höhe-2\>*  | *\<Maßnahme-1\>* |

## Annahmen

| Nr. | Text            |
|-----|-----------------|
| *1* | *\<Annahme-1\>* |
| *2* | *\<Annahme-2\>* |
