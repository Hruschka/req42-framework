# Risiken und Annahmen

<div class="formalpara-title">

**Inhalt**

</div>

(Priorisierte) Listen von Risiken, die Sie erkannt haben und eine Liste
von Annahmen, die Sie als Grundlage für Entscheidungen getroffen haben.

<div class="formalpara-title">

**Motivation**

</div>

„Risikomanagement ist Projektmanagement für Erwachsene“ sagt Tim Lister
von der Atlantic Systems Guild“. In diesem Sinne sollten Sie Ihre
Risiken als Product Owner im Griff halten.

req42 gibt Ihnen die Mittel an die Hand, Risiken bewusst zu managen.
Insbesondere beim Priorisieren Ihrer Anforderungen sollten Sie
ausgewogen zwischen Business Value und Risk Reduction abwägen.

<div class="formalpara-title">

**Notationen/Tools**

</div>

Einfache Tabellen oder Listen reichen oft bereits aus.

## 12.1. Risiken

| Nr. | Text          | Wahrschein-lichkeit | Schadens-höhe | Evtl. Maßnahmen |
|-----|---------------|---------------------|---------------|-----------------|
| *1* | *\<Risiko-1>* | *\<%-1>*            | *\<Höhe-1>*   | *\<Maßnahme-1>* |
| *2* | *\<Risiko-2>* | *\<%-2>*            | *\<Höhe-2>*   | *\<Maßnahme-1>* |

## 12.2. Annahmen

| Nr. | Text           |
|-----|----------------|
| *1* | *\<Annahme-1>* |
| *2* | *\<Annahme-2>* |
