# Domänenbegriffe

| Bedeutung       | Erläuterung         |
|-----------------|---------------------|
| *\<Begriff-1\>* | *\<Erläuterung-1\>* |
| *\<Begriff-2\>* | *\<Erläuterung-2\>* |
