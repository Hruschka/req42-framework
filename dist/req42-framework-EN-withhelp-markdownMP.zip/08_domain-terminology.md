# Domain Terminology {#section-domain-terminology}

::: formalpara-title
**Content**
:::

A glossary of technical terms with definitions. The \"ubiquitous
language\" of your domain

::: formalpara-title
**Motivation**
:::

Terms from your domain appear in every epic, feature, or story. These
terms should be clear to everyone involved. And that's why it is
desirable to have a glossary of such terms for a project or product
development.

Make sure that everyone involved speaks a common language - and has
access to agreed-upon definitions of terms instead of bringing new words
into play in every meeting.

::: formalpara-title
**Notations/Tools**
:::

Alphabetically ordered list of term definitions

+------------+---------------------------------------------------------+
| Term       | Definition                                              |
+============+=========================================================+
| *          | *\<Definition-1>*                                       |
| \<Term-1>* |                                                         |
+------------+---------------------------------------------------------+
| *          | *\<Definition-2>*                                       |
| \<Term-2>* |                                                         |
+------------+---------------------------------------------------------+
|            |                                                         |
+------------+---------------------------------------------------------+
