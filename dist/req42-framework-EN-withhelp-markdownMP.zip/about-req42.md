# 

**About req42**

req42, the framework for collecting, documenting and communicating
requirements.

Created and maintained by Dr. Peter Hruschka, Markus Meuten and
contributors.

Template Revision: 2.0.1-EN (based on asciidoc), September 2026

© We acknowledge that this document uses material from the req42
framework, <https://req42.de>
