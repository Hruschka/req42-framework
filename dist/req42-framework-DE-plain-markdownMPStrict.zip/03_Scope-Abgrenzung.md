# Scope-Abgrenzung

*&lt;Kontextdiagramm&gt;* oder *&lt;Kontexttabelle&gt;* hier einfügen.

Optional: Tabelle mit Erläuterungen der Schnittstellen ergänzen:

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 75%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Bedeutung</th>
<th style="text-align: left;">Erläuterung</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;IF-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;IF-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-2&gt;</em></p></td>
</tr>
</tbody>
</table>
