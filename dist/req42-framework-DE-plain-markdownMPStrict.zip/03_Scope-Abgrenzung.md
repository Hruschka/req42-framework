# Scope-Abgrezung

**Inhalt**

Ihr Produkt mit allen externen Schnittstellen zu (menschlichen und
automatisierten) Nachbarn, bzw. Nachbarsystemen

**Motivation**

Scope ist der Bereich, den Sie beeinflussen können. Die Umgebung des
Produktes, zu dem es sicherlich viele Schnittstellen gibt stellt den
Kontext dar. Der Kontext kann (normalerweise) nicht von Ihnen allein
entschieden werden, kann aber oft verhandeln werden. Um Klarheit zu
gewinnen ist es wichtig beides möglichst zu beschreiben und vor allem
die Grenze zwischen den beiden Bereichen zu definieren. req42 empfiehlt
Ihnen mit dem Business-Scope zu beginnen und nicht zu früh den
Product-Scope einzuschränken.

Die Entscheidung über die Produktgrenze sollte eine bewusste
Entscheidung sein. Mehr über dieses unverzichtbare Thema lesen Sie im
Blog-Beitrag „Scope ist nicht gleich Scope“. In unseren Kursen üben Sie
die Scope-Abgrenzung anhand einer realistischen Fallstudie.

**Notationen/Tools**

Zur Darstellung der Scope-Abgrenzung gibt es viele verschiedene
Ausdrucksmittel, aber eine gute Scope-Abgrenzung macht die
Schnittstellen zum Kontext explizit (z.B. in Form von Ein- und Ausgaben,
von angebotenen und benötigten Services, …)

-   Diverse Formen von Kontextdiagrammen

-   Kontexttabelle

*&lt;Kontextdiagramm>* oder *&lt;Kontexttabelle>* hier einfügen.

Optional: Tabelle mit Erläuterungen der Schnittstellen ergänzen:

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 75%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Bedeutung</th>
<th style="text-align: left;">Erläuterung</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;IF-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;IF-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-2&gt;</em></p></td>
</tr>
</tbody>
</table>
