# Product Backlog

EPIC 1: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;* damit
*&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

FEATURE 1.1: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 1.1.1.: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 1.1.x.: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

EPIC 2: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;* damit
*&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

FEATURE 2.1: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 2.1.1.: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 2.1.2: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

FEATURE 2.2: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 2.2.1.: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 2.2.2: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

EPIC 3: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;* damit
*&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.
