# Stakeholder

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 19%" />
<col style="width: 32%" />
<col style="width: 32%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rolle</th>
<th style="text-align: left;">Person</th>
<th style="text-align: left;">Thema</th>
<th style="text-align: left;">Einfluss</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Rolle-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Thema-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Einfluss-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Rolle-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Thema-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Einfluss-2&gt;</em></p></td>
</tr>
</tbody>
</table>
