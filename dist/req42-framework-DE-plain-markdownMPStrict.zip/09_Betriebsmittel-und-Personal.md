# Betriebsmittel und Personal

## Budget

(evtl. gegliedert nach Roadmap oder Zwischenzielen, bzw. aufgeteilt in
Personalbudget, Sachbudget, …​)

## Zeitrahmen/Endtermin

## Teammitglieder

(Aufzählung oder aber ein Link auf komplexe Teamstruktur in Abschnitt
10)

## Externe Ressourcen
