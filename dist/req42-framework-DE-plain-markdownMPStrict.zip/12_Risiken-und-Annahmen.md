# Risiken und Annahmen

**Inhalt**

(Priorisierte) Listen von Risiken, die Sie erkannt haben und eine Liste
von Annahmen, die Sie als Grundlage für Entscheidungen getroffen haben.

**Motivation**

„Risikomanagement ist Projektmanagement für Erwachsene“  sagt Tim Lister
von der Atlantic Systems Guild“.  In diesem Sinne sollten Sie Ihre
Risiken als Product Owner im Griff halten. req42 gibt Ihnen die Mittel
an die Hand, Risiken bewusst zu managen. Insbesondere beim Priorisierung
Ihrer Anforderungen sollten Sie ausgewogen zwischen Business Value und
Risk Reduction abwägen.

**Notationen/Tools**

Einfache Tabellen oder Listen reichen oft bereits aus.

Siehe [Risiken und technische
Schulden](https://docs.arc42.org/section-11/) in der
online-Dokumentation (auf Englisch!).

## Risiken

<table>
<colgroup>
<col style="width: 11%" />
<col style="width: 33%" />
<col style="width: 11%" />
<col style="width: 11%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Nr.</th>
<th style="text-align: left;">Text</th>
<th style="text-align: left;">Wahrscheinlichkeit</th>
<th style="text-align: left;">Schadenshöhe</th>
<th style="text-align: left;">Evtl. Maßnahmen</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Risiko-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;%-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Höhe-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Maßnahme-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Risiko-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;%2-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Höhe-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Maßnahme-1&gt;</em></p></td>
</tr>
</tbody>
</table>

## Annahmen

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 83%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Nr.</th>
<th style="text-align: left;">Text</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Annahme-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Annahme-2&gt;</em></p></td>
</tr>
</tbody>
</table>
