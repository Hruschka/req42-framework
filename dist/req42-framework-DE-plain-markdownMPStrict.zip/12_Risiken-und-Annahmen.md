# Risiken und Annahmen

## Risiken

<table style="width:100%;">
<colgroup>
<col style="width: 7%" />
<col style="width: 38%" />
<col style="width: 7%" />
<col style="width: 7%" />
<col style="width: 38%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Nr.</th>
<th style="text-align: left;">Text</th>
<th style="text-align: left;">Wahrschein-lichkeit</th>
<th style="text-align: left;">Schadens-höhe</th>
<th style="text-align: left;">Evtl. Maßnahmen</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>1</em></p></td>
<td style="text-align: left;"><p><em>&lt;Risiko-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;%-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Höhe-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Maßnahme-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>2</em></p></td>
<td style="text-align: left;"><p><em>&lt;Risiko-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;%-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Höhe-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Maßnahme-1&gt;</em></p></td>
</tr>
</tbody>
</table>

## Annahmen

<table>
<colgroup>
<col style="width: 9%" />
<col style="width: 90%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Nr.</th>
<th style="text-align: left;">Text</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>1</em></p></td>
<td style="text-align: left;"><p><em>&lt;Annahme-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>2</em></p></td>
<td style="text-align: left;"><p><em>&lt;Annahme-2&gt;</em></p></td>
</tr>
</tbody>
</table>
