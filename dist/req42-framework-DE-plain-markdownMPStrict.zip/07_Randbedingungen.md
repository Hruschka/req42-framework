# Randbedingungen

**Inhalt**

Technologische oder organisatorische Randbedingungen, bzw.
Randbedingungen für den Entwicklungsprozess, wie verpflichtende
Tätigkeiten, vorgeschriebene Dokumente und deren Inhalt, einzuhaltenden
Meilensteine, …

**Motivation**

Auch solche Randbedingungen sind Anforderungen. Und da sie oft für
mehrere oder sogar alle funktionalen Anforderungen gelten, sind sie
schwer in dem geordneten Product Backlog unterzubringen. Stellen Sie
einfach sicher, dass alle Beteiligten diese Randbedingungen kennen und
bei Bedarf Zugriff dazu haben.

**Notationen/Tools**

Einfache Listen, evtl. nach Kategorien geordnet.

Siehe [Architekturentscheidungen](https://docs.arc42.org/section-9/) in
der arc42 Dokumentation (auf Englisch!). Dort finden Sie Links und
Beispiele zum Thema ADR.

## Organisatorische Randbedingungen

-   .

-   .

-   .

## Technische Randbedingungen

-   .

-   .

-   .
