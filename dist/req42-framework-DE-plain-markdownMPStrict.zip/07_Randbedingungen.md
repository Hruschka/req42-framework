# Randbedingungen

## Organisatorische Randbedingungen

\* \* \*

## Technische Randbedingungen

\* \* \*
