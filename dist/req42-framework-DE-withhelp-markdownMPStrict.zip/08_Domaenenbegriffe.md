# Domänenbegriffe

**Inhalt**

Ein Glossar von fachlichen Begriffen mit Definitionen.

**Motivation**

In jedem Epic, Feature oder Story kommen Begriffe aus Ihrer Domäne vor.
Diese Begriffe sollten allen Beteiligten klar sein. Und deshalb ist es
wünschenswert, für ein Projekt oder eine Produktentwicklung ein Glossar
solcher Begriffe zu haben. Stellen Sie sicher, dass alle Beteiligten
eine gemeinsame Sprache sprechen – und im Zweifelsfall Zugriff auf
vereinbarte Begriffsdefinitionen haben, statt in jedem Meeting wieder
neue Wörter ins Spiel zu bringen.

**Notationen/Tools**

Alphabetisch geordnete Liste von Begriffsdefinitionen

Siehe [Laufzeitsicht](https://docs.arc42.org/section-6/) in der
online-Dokumentation (auf Englisch!).

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 75%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Bedeutung</th>
<th style="text-align: left;">Erläuterung</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Begriff-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Begriff-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-2&gt;</em></p></td>
</tr>
</tbody>
</table>
