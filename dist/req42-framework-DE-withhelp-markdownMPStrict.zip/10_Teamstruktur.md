# Teamstruktur

**Inhalt**

Bei kleinen Produktentwicklungen mit nur einem Entwicklungsteam kann
dieser Abschnitt entfallen, da die Teammitglieder bereits im vorherigen
Abschnitt aufgeführt sind. Bei skalierten großen Produkten sollte hier
das Organigramm Ihrer Teams stehen und eine Zuordnung zu den Themen
(z.B. Epics, Features, …), für die dieses Team zuständig ist.

**Motivation**

Wenn Sie über mehrere Teams verfügen, ist es selbstverständlich, dass
Sie einen Überblick darüber haben, wer in welchem (Sub-)Team arbeitet
und wie diese Teams organisiert sind. Der Fokus sollte darauf liegen,
dass die (Teil-)Teams so organisiert sind, dass sie möglichst
selbstständig Funktionen/Features oder Teilprodukte liefern können, ohne
sich ständig mit allen anderen abstimmen zu müssen.

**Notationen/Tools**

Listen von Teams (jeweils mit zugewiesenen Personen und zugewiesenen
Themen aus der Roadmap oder aus dem Product Backlog (z. B. Epics oder
Features).

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Team</th>
<th style="text-align: left;">Team-Mitglied</th>
<th style="text-align: left;">Themen</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><a href="#Team-1">???</a></p></td>
<td style="text-align: left;"><p>PO: <a href="#Name">???</a></p></td>
<td style="text-align: left;"><p><a href="#Teilprodukt-A">???</a></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><a href="#Team-Member-1">???</a></p></td>
<td style="text-align: left;"></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><a href="#Team-2">???</a></p></td>
<td style="text-align: left;"><p>PO: <a href="#Name">???</a></p></td>
<td style="text-align: left;"><p><a href="#Teilprodukt-B">???</a></p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><a href="#Team-Member-1">???</a></p></td>
<td style="text-align: left;"></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><a href="#Team-Member-2">???</a></p></td>
<td style="text-align: left;"></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
