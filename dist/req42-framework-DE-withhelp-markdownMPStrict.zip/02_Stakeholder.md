# Stakeholder

Inhalt

Eine (priorisierte) Liste Ihrer Stakeholder, zusammen Angaben, wo diese
Stakeholder bei der Analysearbeit helfen (oder hindern) können.

Motivation

Stakeholder sind die wichtigsten Quellen für Anforderungen. Deshalb
sollten Sie diese kennen und dokumentieren. Sie müssen wissen, wer davon
Ihnen wobei helfen oder Sie in welcher Form behindern kann. Sie müssen
wissen, wer welchen Einfluss hat – und bei unterschiedlichen Meinungen
müssen Sie vermitteln oder entscheiden.

Ohne explizit identifizierte Stakeholder ist das alles schwierig.

Notationen/Tools

- Tabellen oder Listen (einfache Form)

- Evtl. Stakeholder-Map (komplexere Form)

Nachfolgend haben wir als Beispiel eine einfache Stakeholder-Liste
eingefügt.

Die Reihenfolge "Rolle vor Person" ist bewusst gewählt. Diese
Reihenfolge hat sich bewährt da Anforderungen normalerweise immer
Bedarfe aus Sicht einer Rolle darstellen, die Person, welche die Rolle
einnimmt während des Projektes aber durchaus wechseln kann.

Sie können bei Bedarf auch gerne weitere Spalten hinzufügen
(Kontaktdaten, …) – bedenken Sie aber den Aufwand für deren Pflege.

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 19%" />
<col style="width: 32%" />
<col style="width: 32%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Rolle</th>
<th style="text-align: left;">Person</th>
<th style="text-align: left;">Thema</th>
<th style="text-align: left;">Einfluss</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Rolle-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Thema-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Einfluss-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Rolle-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Thema-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Einfluss-2&gt;</em></p></td>
</tr>
</tbody>
</table>
