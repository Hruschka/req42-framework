# Risks & Assumptions

Content

(Prioritized) lists of risks you have identified and a list of
assumptions you have made as a basis for decisions.

Motivation

"Risk management is project management for adults" says Tim Lister of
the Atlantic Systems Guild".

With this in mind, you should keep your risks under control as a product
owner.

req42 provides you with the means to consciously manage risks.
Especially when prioritizing your requirements you should balance
business value and risk reduction.

Notations/Tools

Simple tables or lists are often already sufficient.

## Risks

<table>
<colgroup>
<col style="width: 11%" />
<col style="width: 33%" />
<col style="width: 11%" />
<col style="width: 11%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Id</th>
<th style="text-align: left;">Text</th>
<th style="text-align: left;">Probability</th>
<th style="text-align: left;">Damage Amount</th>
<th style="text-align: left;">Possible Measures</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

## Assumptions

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 83%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Id</th>
<th style="text-align: left;">Text</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
