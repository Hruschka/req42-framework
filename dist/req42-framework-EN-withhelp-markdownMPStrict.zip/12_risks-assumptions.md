# Risks & Assumptions

**Content**

(Prioritized) lists of risks you have identified and a list of
assumptions you have made as a basis for decisions.

**Motivation**

"Risk management is project management for adults" says Tim Lister of
the Atlantic Systems Guild". With this in mind, you should keep your
risks under control as a product owner. req42 provides you with the
means to consciously manage risks. Especially when prioritizing your
requirements you should balance business value and risk reduction.

**Notations/Tools**

Simple tables or lists are often already sufficient.

Siehe [Glossar](https://docs.arc42.org/section-12/) in der
online-Dokumentation (auf Englisch!).

## 12.1. Risks

<table style="width:100%;">
<colgroup>
<col style="width: 16%" />
<col style="width: 51%" />
<col style="width: 16%" />
<col style="width: 16%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Id</th>
<th style="text-align: left;">Text</th>
<th style="text-align: left;">Probability</th>
<th style="text-align: left;">Damage Amount</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p>Possible Measures</p></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

## 12.2. Assumptions

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 83%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Id</th>
<th style="text-align: left;">Text</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
