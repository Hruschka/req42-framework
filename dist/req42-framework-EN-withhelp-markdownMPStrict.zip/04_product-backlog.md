# Product Backlog

Content

An ordered list of product backlog items (at different levels of
granularity: e.g. epics, features and user stories). Backlog items
should be prioritized (better term: ranked) among each other.

The items with the greatest added value in terms of implementation
effort should be at the top of the backlog to be implemented next.

You have to define explicitly what added value means for you and your
development. The simplest definition is the business added value for the
customer when implementing the requirement.

Motivation

The Scrum Guide defines:

"The Product Backlog is an ordered list of everything that is known to
be included in the product. It serves as the single source of
requirements for all changes to the product. The Product Owner is
responsible for the Product Backlog, its contents, access to it, and the
order of entries. A Product Backlog is never complete. During its
initial development steps, it identifies the requirements that are
initially known and best understood. The Product Backlog evolves with
the product and its use. It is dynamic; it constantly adapts to make
clear for the product what it needs to be adequate to its task, to
compete, and to provide the required benefits."

As long as a product exists, so does its Product Backlog. So you see:
the Product Backlog is really important for successful work as a Product
Owner. But please fill in the other artifacts as well. Your job may not
start with the Product Backlog and it certainly doesn’t end with the
Product Backlog.

Notations/Tools

Proven (regardless of granularity) for epics, features and user stories
is the formula:

    As <role> I want <functionality> so that <advantage>.

For the more abstract levels (epics, features), compound nouns may also
be suitable for describing functionality.

Use ALM tools or ticket systems (JIRA or Azure DevOps) or wikis (like
Confluence) to manage your epics, features and stories (linked and
ordered).

A two-dimensional representation of the product backlog in the form of a
story map has proven particularly useful.

EPIC 1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

FEATURE 1.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 1.1.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 1.1.x.:As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

EPIC 2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

FEATURE 2.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.1.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.1.2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

FEATURE 2.2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.2.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.2.2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

EPIC 3: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.
