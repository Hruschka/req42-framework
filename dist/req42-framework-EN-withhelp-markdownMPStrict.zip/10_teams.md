# Teams

**Content**

This section can be omitted for small product developments with only one
development team, since the team members are already listed in the
previous section. For scaled large products, the organization chart of
your teams should be here and an assignment to the topics (e.g. epics,
features, …) this team is responsible for.

**Motivation**

If you have more than one team at your disposal, it goes without saying
that you should have an overview of who works in which (sub-)team and
how these teams are organized. The focus should be on (sub-)teams being
organized in such a way that they can deliver functions/features or
partial products as independently as possible without having to
constantly coordinate with everyone else.

**Notations/Tools**

Lists of teams (each with assigned people and assigned topics from the
roadmap or from the product backlog (e.g., epics or features).

Siehe [Qualitätsanforderungen](https://docs.arc42.org/section-10/) in
der online-Dokumentation (auf Englisch!).

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Team</th>
<th style="text-align: left;">Team Members</th>
<th style="text-align: left;">Feature</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Team-1&gt;</em></p></td>
<td style="text-align: left;"><p>PO: <em>&lt;Person-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Feature-A&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team member-2&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team member-3&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Team-2&gt;</em></p></td>
<td style="text-align: left;"><p>PO_&lt;Person-2&gt;_</p></td>
<td style="text-align: left;"><p><em>&lt;Feature-B&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team member-2&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
