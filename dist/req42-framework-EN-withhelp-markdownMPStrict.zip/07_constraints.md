# Constraints

Content

Technological or organizational (mandated) constraints for the
development process, such as mandatory activities, prescribed documents
and their content, milestones to be met, …​

Motivation

Such constraints are also requirements. And since they often apply to
several or even all functional requirements, they are difficult to
accommodate in the ordered product backlog. Just make sure that all
stakeholders know these constraints and have access to them when needed.

Form

Simple lists, possibly organized by category.

## Organizational Constraints

- *&lt;OrgConstraint1&gt;*

- *&lt;OrgConstraint2&gt;*

- *&lt;OrgContraint3&gt;*

## Technical Constraints

- *&lt;TechConstraint1&gt;*

- *&lt;TechConstraint2&gt;*

- *&lt;TechContraint3&gt;*
