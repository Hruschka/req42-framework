# Scope

**Content**

Your product with all external interfaces to (human and automated)
neighbors, resp. neighboring systems.

**Motivation**

Scope is the area that you can influence. The environment of the
product, to which there are certainly many interfaces, represents the
context. The context cannot (usually) be decided by you alone, but can
often be negotiated. To gain clarity it is important to describe both as
much as possible and especially to define the boundary between the two
scopes.

req42 recommends that you start with the business scope and do not limit
the product scope too early. The decision about the product scope should
be a conscious one. Read more about this indispensable topic in the blog
post "Scope is not equal to Scope" or in \[2\]. In our courses, you will
practice scope delimitation using a realistic case study.

**Notations/Tools**

There are many different means of expression for representing scope
delineation, but a good scope delineation makes the interfaces to the
context explicit (e.g., in terms of inputs and outputs, of services
provided and required, …).

-   Various forms of context diagrams

-   Context chart

Insert [???](#Context diagram) or [???](#Context table) here.

Optional: add table with explanations of interfaces:

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 83%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Interface Name</th>
<th style="text-align: left;">Meaning/Explanation</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;IF-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Meaning-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;IF-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Meaning-2&gt;</em></p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
