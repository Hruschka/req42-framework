# Domain Terminology

**Content**

A glossary of technical terms with definitions. The "ubiquitous
language" of your domain

**Motivation**

Terms from your domain appear in every epic, feature, or story. These
terms should be clear to everyone involved. And that’s why it is
desirable to have a glossary of such terms for a project or product
development.

Make sure that everyone involved speaks a common language - and has
access to agreed-upon definitions of terms instead of bringing new words
into play in every meeting.

**Notations/Tools**

Alphabetically ordered list of term definitions

<table>
<colgroup>
<col style="width: 19%" />
<col style="width: 80%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Term</th>
<th style="text-align: left;">Definition</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Term-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Definition-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Term-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Definition-2&gt;</em></p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
