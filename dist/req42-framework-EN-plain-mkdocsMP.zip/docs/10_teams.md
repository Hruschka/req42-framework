# Teams {#section-teams}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

This section can be omitted for small product developments with only one development team, since the team members are already listed in the previous section.

</div>

For scaled large products, the organization chart of your teams should be here and an assignment to the topics (e.g. epics, features, …​) this team is responsible for.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

If you have more than one team at your disposal, it goes without saying that you should have an overview of who works in which (sub-)team and how these teams are organized.

</div>

The focus should be on (sub-)teams being organized in such a way that they can deliver functions/features or partial products as independently as possible without having to constantly coordinate with everyone else.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

Lists of teams (each with assigned people and assigned topics from the roadmap or from the product backlog (e.g., epics or features).

</div>

</div>

| Team             | Team Members            | Feature             |
|------------------|-------------------------|---------------------|
| *&lt;Team-1&gt;* | PO: *&lt;Person-1&gt;*  | *&lt;Feature-A&gt;* |
|                  | *&lt;Team member-2&gt;* |                     |
|                  | *&lt;Team member-3&gt;* |                     |
|                  |                         |                     |
| *&lt;Team-2&gt;* | PO\_&lt;Person-2&gt;\_  | *&lt;Feature-B&gt;* |
|                  | *&lt;Team member-2&gt;* |                     |
|                  |                         |                     |

  [Teams]: #section-teams {#toc-section-teams}
