# Stakeholder {#section-stakeholder}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

A (prioritized) list of your stakeholders, along with indications of where these stakeholders can help (or hinder) the analysis work.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Stakeholders are the most important sources for requirements. Therefore, you should know and document them. You need to know who can help you with what or hinder you in what way. You need to know who has what influence - and if opinions differ, you need to mediate or decide. Without explicitly identified stakeholders, all this is difficult.

</div>

<div markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

- Tables or lists (simple form)

- Possibly stakeholder map (more complex form)

</div>

Below we have included a simple stakeholder list as an example.

The order "role before person" has been chosen deliberately. This order has proven itself since requirements normally always represent needs from the perspective of a role, but the person taking on the role can change during the project.

If required, you can also add further columns (contact data, …​) - but consider the effort for their maintenance.

</div>

| Role             | Person             | Topic             | Influence             |
|---------------|----------------------------|---------------|---------------|
| *&lt;Role-1&gt;* | *&lt;Person-1&gt;* | *&lt;Topic-1&gt;* | \_&lt;Influence-1&gt; |
| *&lt;Role-2&gt;* | *&lt;Person-2&gt;* | *&lt;Topic-2&gt;* | \_&lt;Influence-2&gt; |
|                  |                    |                   |                       |

  [Stakeholder]: #section-stakeholder {#toc-section-stakeholder}
