# Roadmap {#section-roadmap}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

"Delivery artifacts put on the timeline" - who delivers what and when?

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Agile projects also need a plan. The more distant a goal is, the less precise the plan can be. The closer, the more precise.

</div>

An explicitly known roadmap enables all participants to coordinate with each other and to think along with each other, and therefore to take into account what is still to come in the medium term when making short-term decisions.

If you only live from hand to mouth, you may unknowingly make short-term decisions that are contrary to longer-term product success. In our courses we show you how rough or fine a roadmap can, may or should be.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

Whatever you have in use as a planning tool or which allows you to present, if possible on one page, an appropriate overview over a longer period of time.

</div>

</div>

*&lt; Insert your planning here&gt;*

  [Roadmap]: #section-roadmap {#toc-section-roadmap}
