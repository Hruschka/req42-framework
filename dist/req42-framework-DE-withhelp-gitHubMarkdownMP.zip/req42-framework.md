# 

**Über req42**

req42, das Framework zur Sammlung, Dokumentation und Kommunikation von
Anforderungen im agilen Umfeld.

Erstellt von Dr. Peter Hruschka, Markus Meuten und Mitwirkenden.

Template Revision: 2.0 DE (asciidoc-based), August 2022

© We acknowledge that this document uses material from the req42
architecture framework, <https://req42.de>

<div class="note">

Diese Version des Frameworks enthält Hilfen und Erläuterungen. Sie dient
der Einarbeitung in req42 sowie dem Verständnis der Konzepte. Für die
Dokumentation eigener System verwenden Sie besser die *plain* Version.

</div>

# Visionen und Ziele

<div class="formalpara-title">

**Inhalt**

</div>

Die Business-Ziele Ihrer Produktentwicklung bzw. Ihres Projekts.
Stakeholder-verständlich und transparent.

<div class="formalpara-title">

**Motivation**

</div>

Die Ziele müssen so weit präzisiert und abgestimmt werden, dass alle
Beteiligten eine klare Vorstellung davon haben, was in welchen
Zeiträumen erreicht werden soll. Die Festlegung von Visionen und Zielen
leitet das Team bei der Ausarbeitung der detaillierten Anforderungen und
vermeidet Verzettelung. Vielleicht haben Ihnen Ihre Auftraggeber grobe
Ziele oder eine Vision mitgegeben, als man Sie mit der Rolle des Product
Owners betraut hat. Oft reicht jedoch die Präzision dieser Vorgaben
nicht aus, um ein Team systematisch zum Erfolg zu führen. Für uns gilt:
Ziele sind Anforderungen! Oder präziser: Ziele sind die Anforderungen,
die sich hoffentlich in dem Zeitraum, für den sie definiert werden,
stabil bleiben.

<div class="formalpara-title">

**Form**

</div>

Zur Definition von Zielen stehen Ihnen verschiedenste Ausdrucksmittel
zur Verfügung, die Sie nach Lust und Laune wählen können. Unsere
Empfehlung: \* Notation in Form von PAM (Purpose, Advantage, Metric)
Alternative Notationsformen: \* Produktkoffer \* News from the Future \*
Product Canvas \* Value Proposition Nur eines sollten Sie nie machen:
Ohne explizite Ziele oder Visionen zu arbeiten.

Siehe [Anforderungen und Ziele](https://docs.arc42.org/section-1/) in
der online-Dokumentation (auf Englisch!).

Zieldefinitionen nach PAM:

Ziel 1: Vorteil 1: Metrik 1:

Ziel 2: Vorteil 2: Metrik 2:

Ziel 3: Vorteil 3: Metrik 3:

# Scope-Abgrezung

<div class="formalpara-title">

**Inhalt**

</div>

Ihr Produkt mit allen externen Schnittstellen zu (menschlichen und
automatisierten) Nachbarn, bzw. Nachbarsystemen

<div class="formalpara-title">

**Motivation**

</div>

Scope ist der Bereich, den Sie beeinflussen können. Die Umgebung des
Produktes, zu dem es sicherlich viele Schnittstellen gibt stellt den
Kontext dar. Der Kontext kann (normalerweise) nicht von Ihnen allein
entschieden werden, kann aber oft verhandeln werden. Um Klarheit zu
gewinnen ist es wichtig beides möglichst zu beschreiben und vor allem
die Grenze zwischen den beiden Bereichen zu definieren. req42 empfiehlt
Ihnen mit dem Business-Scope zu beginnen und nicht zu früh den
Product-Scope einzuschränken. Die Entscheidung über die Produktgrenze
sollte eine bewusste Entscheidung sein. Mehr über dieses unverzichtbare
Thema lesen Sie im Blog-Beitrag „Scope ist nicht gleich Scope“ oder in
\[2\]. In unseren Kursen üben Sie die Scope-Abgrenzung anhand einer
realistischen Fallstudie.

<div class="formalpara-title">

**Notationen/Tools**

</div>

Zur Darstellung der Scope-Abgrenzung gibt es viele verschiedene
Ausdrucksmittel, aber eine gute Scope-Abgrenzung macht die
Schnittstellen zum Kontext explizit (z.B. in Form von Ein- und Ausgaben,
von angebotenen und benötigten Services, …) \* Diverse Formen von
Kontextdiagrammen \* Kontexttabelle

Siehe [Lösungsstrategie](https://docs.arc42.org/section-4/) in der
online-Dokumentation (auf Englisch!).

[???](#Kontextdiagramm) oder [???](#Kontexttabelle) hier einfügen.

Optional: Tabelle mit Erläuterungen der Schnittstellen ergänzen:

| Bedeutung | Erläuterung        |
|-----------|--------------------|
| *\<IF-1>* | *\<Erläuterung-1>* |
| *\<IF-2>* | *\<Erläuterung-2>* |

# Product Backlog

<div class="formalpara-title">

**Inhalt**

</div>

Eine geordnete Liste von Product Backlog Items (auf verschiedenem
Granularitätsstufen: z.B. Epics, Features und User Storys.)
Backlog-Items sollen untereinander priorisiert (besserer Ausdruck:
geranked) sein. Die Items mit dem größten Mehrwert bezogen auf den
Umsetzungsaufwand sollten sich entsprechend oben im Backlog
wiederfinden, um als nächstes umgesetzt zu werden. Was Mehrwert für Sie
und Ihre Entwicklung bedeutet müssen Sie explizit festlegen. Die
einfachste Ausprägung ist der Business Mehrwert für den Kunden bei
Umsetzung der Anforderung.

<div class="formalpara-title">

**Motivation**

</div>

Der Scrum Guide \[1\] definiert: „Das Product Backlog ist eine geordnete
Liste von allem, von dem bekannt ist, dass es im Produkt enthalten sein
soll. Es dient die einzige Anforderungsquelle für alle Änderungen am
Produkt. Der Product Owner ist für das Product Backlog, seine Inhalte,
den Zugriff darauf und die Reihenfolge der Einträge verantwortlich. Ein
Product Backlog ist niemals vollständig. Während seiner ersten
Entwicklungsschritte zeigt es die anfangs bekannten und am besten
verstandenen Anforderungen auf. Das Product Backlog entwickelt sich mit
dem Produkt und dessen Einsatz weiter. Es ist dynamisch; es passt sich
konstant an, um für das Produkt klar herauszustellen, was es braucht, um
seiner Aufgabe angemessen zu sein, im Wettbewerb zu bestehen und den
erforderlichen Nutzen zu bieten.“  Solange ein Produkt existiert,
existiert auch sein Product Backlog. Sie sehen also: das Product Backlog
ist wirklich wichtig für die erfolgreiche Arbeit als Product Owner. Aber
bitte füllen sie auch die anderen Artefakt. Ihr Job fängt vielleicht
nicht mit dem Product Backlog an und hört sicherlich nicht mit dem
Product Backlog auf.

<div class="formalpara-title">

**Notationen/Tools**

</div>

Bewährt hat sich (unabhängig von der Granularität) für Epics, Features
und User-Storys die Formel: Als [???](#Rolle) möchte ich
[???](#Funktionalität) damit [???](#Vorteil). Für die abstrakteren
Ebenen (Epics, Features) eignen sich unter Umständen auch
zusammengesetzte Substantive zum Beschreiben der Funktionalität. Nutzen
Sie ALM Tools bzw. Ticket-Systeme (JIRA oder Azure DevOps) oder Wikis
(wie Confluence), um Ihre Epics, Features und Storys (verlinkt und
geordnet) zu verwalten. Besonders bewährt hat sich eine zweidimensionale
Darstellung des Product Backlogs in Form einer Story-Map.

Siehe [Bausteinsicht](https://docs.arc42.org/section-5/) in der
online-Dokumentation (auf Englisch!).

EPIC 1: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

FEATURE 1.1: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

STORY 1.1.1.: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

STORY 1.1.x.: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

EPIC 2: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

FEATURE 2.1: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

STORY 2.1.1.: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

STORY 2.1.2: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

FEATURE 2.2: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

STORY 2.2.1.: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

STORY 2.2.2: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

EPIC 3: Als [???](#Rolle) möchte ich [???](#Funktionalität) damit
[???](#Vorteil) [???](#optional. Link zu Modellen).

# Modelle zur Unterstützung

<div class="formalpara-title">

**Inhalt**

</div>

Jegliche Art von grafischen Modellen, die das Verständnis (von
Zusammenhängen) von Backlog Items erleichtern. Die Diagramme sollten mit
Items aus dem Product Backlog verlinkt sein.

<div class="formalpara-title">

**Motivation**

</div>

In der agilen Welt hat es sich weit verbreitet, Anforderungen in Form
von Epics, Features oder User Storys auf Kärtchen zu schreiben oder in
äquivalenter Form in Tools abzulegen. Trotzdem wird die Kommunikation
unter allen Beteiligten manchmal erheblich einfacher, wenn man
zusätzlich auch die Hilfsmittel verwendet, die wir in den letzten
Jahrzehnten zur Präzisierung der Umgangssprache kennengelernt haben.
Scheuen Sie also nicht davor zurück Modelle zu verwenden, wenn sie die
Kommunikation fördern. Keine Angst: diese Modelle müssen nicht perfekt
sein. Aber insbesondere mir anwachsender Komplexität (Schleifen oder
Fallunterscheidungen) fördert eine grafische Visualisierung der Schritte
eines Geschäftsprozesses das Verständnis besser als viele Tickets im
System ohne erkennbare Abfolgen und Abhängigkeiten.

-   Flussdiagramme

-   Aktivitätsdiagramme

-   BPMN

-   Zustandsmodelle

-   Datenmodelle

-   UI-Prototypen

-   Mock-ups

-   Wireframes

Einfache Modellierungstools wie Gliffy, Diagrams.Net (früher DrawIO),
……, oder DSLs wie PlantUML, Kroki, … oder UML-Modellierungstools wie
Enterprise Architect, Visual Paradigm, MagicDraw eignen sich zum
Erstellen der Modelle. Die Modelle sollten mit Ihren Backlog-Items
verlinkt sein (in beide Richtungen)

Siehe [Verteilungssicht](https://docs.arc42.org/section-7/) in der
online-Dokumentation (auf Englisch!).

[???](#Diagrammtitel 1:).
[???](#hier Diagramm und evtl. Erläuterungen einfügen) [Features oder
Storys](#optional: Link zu Epics)

[???](#Diagrammtitel 2:).
[???](#hier Diagramm und evtl. Erläuterungen einfügen) [Features oder
Storys](#optional: Link zu Epics)

[???](#Diagrammtitel 3:).
[???](#hier Diagramm und evtl. Erläuterungen einfügen) [Features oder
Storys](#optional: Link zu Epics)

    <<Diagrammtitel n:>>. <<hier Diagramm und evtl. Erläuterungen einfügen>> <<optional: Link zu Epics, Features oder Storys>>

    <<<<
    [[section-Qualitaetsanforderungen]]
    == Qualitätsanforderungen

    [role="req42help"]
    ****
    .Inhalt
    Anforderungen an Qualitäten sind das "Wie" zum "Was" – qualitative Definitionen oder Präzisierungen der funktionalen Anforderungen.

    .Motivation
    Unsere Erfahrung zeigt: Qualitätsanforderungen sind (leider) nicht nur in der agilen Welt immer noch heftig unterschätzt. Jeder will qualitativ gute Produkte und Services, aber nur wenige machen es explizit, was damit genau gemeint ist.
    Einige Qualitätsanforderungen (wie Antwortzeiten) lassen sich vielleicht direkt in eine Story integrieren (oder als Abnahmekriterium dazuschreiben). Die große Mehrheit an Qualitätsanforderungen bezieht sich jedoch auf viele, wenn nicht sogar auf alle funktionalen Anforderungen des Product Backlogs. Deshalb brauchen Sie als Product Owner irgendwo die Möglichkeit, die gewünschten Qualitäten Ihrer Produkte und Services zu spezifizieren und zuzuweisen.
    Für diese Tätigkeit stehen Ihnen industrie-erprobten Checklisten (wie ISO 25010 und andere) zur Verfügung, welche Ihnen helfen, rasch die wichtigsten Kategorien zu identifizieren und managen zu können.

    .Notationen/Tools
    Einfache textuelle Szenarien, evtl. nach den Kapiteln des ISO 25010 Qualitätsbaums oder nach VOLERE gegliedert.


    .Weiterführende Informationen

    Siehe https://docs.arc42.org/section-8/[Querschnittliche Konzepte] in der online-Dokumentation (auf Englisch).

    ****

    <<Text Qualitätsanforderungen bzw. -Szenario 1>> :
    <<Link auf funktionale Anforderungen bzw. Gültigkeitsbereich>>

    <<Text Qualitätsanforderungen bzw. -Szenario 2>>:
    <<Link auf funktionale Anforderungen bzw. Gültigkeitsbereich>>

    <<Text Qualitätsanforderungen bzw. -Szenario 3>>:
    <<Link auf funktionale Anforderungen bzw. Gültigkeitsbereich>>
    .....
    .....
    .....
    <<Text Qualitätsanforderungen bzw. -Szenario n>>:
    <<Link auf funktionale Anforderungen bzw. Gültigkeitsbereich>>

    <<<<
    [[section-Randbedingungen]]
    == Randbedingungen

    [role="req42help"]
    ****
    .Inhalt
    Technologische oder organisatorische Randbedingungen, bzw. Randbedingungen für den Entwicklungsprozess, wie verpflichtende Tätigkeiten, vorgeschriebene Dokumente und deren Inhalt, einzuhaltenden Meilensteine, ...

    .Motivation
    Auch solche Randbedingungen sind Anforderungen. Und da sie oft für mehrere oder sogar alle funktionalen Anforderungen gelten, sind sie schwer in dem geordneten Product Backlog unterzubringen. Stellen Sie einfach sicher, dass alle Beteiligten diese Randbedingungen kennen und bei Bedarf Zugriff dazu haben.

    .Notationen/Tools
    Einfache Listen, evtl. nach Kategorien geordnet.

    .Weiterführende Informationen

    Siehe https://docs.arc42.org/section-9/[Architekturentscheidungen] in der arc42 Dokumentation (auf Englisch!).
    Dort finden Sie Links und Beispiele zum Thema ADR.

    ****

    === 7.1 Organisatorische Randbedingungen
    *
    *
    *

    === 7.2 Technische Randbedingungen
    *
    *
    *

    <<<<
    [[section-Domaenenbegriffe]]
    == Domänenbegriffe

    [role="req4242help"]
    ****
    .Inhalt
    Ein Glossar von fachlichen Begriffen mit Definitionen.

    .Motivation
    In jedem Epic, Feature oder Story kommen Begriffe aus Ihrer Domäne vor. Diese Begriffe sollten allen Beteiligten klar sein. Und deshalb ist es wünschenswert, für ein Projekt oder eine Produktentwicklung ein Glossar solcher Begriffe zu haben. Stellen Sie sicher, dass alle Beteiligten eine gemeinsame Sprache sprechen – und im Zweifelsfall Zugriff auf vereinbarte Begriffsdefinitionen haben, statt in jedem Meeting wieder neue Wörter ins Spiel zu bringen.

    .Notationen/Tools
    Alphabetisch geordnete Liste von Begriffsdefinitionen

    .Weiterführende Informationen

    Siehe https://docs.arc42.org/section-6/[Laufzeitsicht] in der online-Dokumentation (auf Englisch!).

    ****

    [cols="1,3" options="header"]
    |===
    |Bedeutung |Erläuterung
    | _<Begriff-1>_ | _<Erläuterung-1>_
    | _<Begriff-2>_ | _<Erläuterung-2>_
    |===

    <<<<
    [[section-Betriebsmittel-und-Personal]]
    == Betriebsmittel und Personal

    [role="req42help"]
    ****
    .Inhalt
    Unter Betriebsmittel und Personal („Assets“) fassen wir das zusammen, was Ihnen Ihre Auftraggeber oder Chefs mitgeben, um Sie als Product Owner (zusammen mit Ihrem Team) zu befähigen, Ihren Job erfolgreich auszuführen.
    Die Assets schließen auf jeden Fall Zeit und Budget ein, d.h. Mittel, die man Ihnen für Ihre Aufgabe zur Verfügung stellt. Vielleicht müssen Sie sich Ihr Team mit diesen Mitteln selbst besorgen oder man stellt Ihnen auch Personal (Ihr Team), Arbeitsräume, Infrastruktur, etc. zur Verfügung.


    .Motivation
    Wenn Sie den Job als Product Owner übernehmen, dann müssen Sie über diese Assets mit Ihren Auftraggebern verhandeln und sicherlich im Endeffekt über deren Verwendung auch (durch hoffentlich erfolgreiche Ergebnisse) Rechenschaft ablegen.
    Auf jeden Fall sollten Sie wissen, was Ihnen an Geld, Personal, Zeit, Infrastruktur, ... zur Verfügung steht. Diese Assets sind eine wesentliche Randbedingung für Ihre Arbeit als Product Owner.

    .Notationen/Tools
    Einfache Listen, Tabellen


    .Weiterführende Informationen

    Siehe https://docs.arc42.org/section-2/[Randbedingungen] in der online-Dokumentation (auf Englisch!).

    ****

    === 9.1 Budget:
    (evtl. gegliedert nach Roadmap oder Zwischenzielen, bzw. aufgeteilt in Personalbudget, Sachbudget, ...)

    === 9.2 Zeitrahmen/Endtermin:

    === 9.3 Teammitglieder:
    (Aufzählung oder aber ein Link auf komplexe Teamstruktur in Abschnitt 10)

    === 9.4 Externe Ressourcen:

    <<<<
    [[section-Teamstruktur]]
    == Teamstruktur

    [role="req42help"]
    ****
    .Inhalt
    Bei kleinen Produktentwicklungen mit nur einem Entwicklungsteam kann dieser Abschnitt entfallen, da die Teammitglieder bereits im vorherigen Abschnitt aufgeführt sind.  Bei skalierten großen Produkten sollte hier das Organigramm Ihrer Teams stehen und eine Zuordnung zu den Themen (z.B. Epics, Features, ...), für die dieses Team zuständig ist.


    .Motivation
    Wenn Sie über mehrere Teams verfügen, ist es selbstverständlich, dass Sie einen Überblick darüber haben, wer in welchem (Sub-)Team arbeitet und wie diese Teams organisiert sind.
    Der Fokus sollte darauf liegen, dass die (Teil-)Teams so organisiert sind, dass sie möglichst selbstständig Funktionen/Features oder Teilprodukte liefern können, ohne sich ständig mit allen anderen abstimmen zu müssen.

    .Notationen/Tools
    Listen von Teams (jeweils mit zugewiesenen Personen und zugewiesenen Themen aus der Roadmap oder aus dem Product Backlog (z. B. Epics oder Features).

    ****

    [cols="1,2,2" options="header"]
    |===
    |Team |Team-Mitglied |Themen
    |<<Team-1>> |PO: <<Name>> | <<Teilprodukt-A>>
    |           |<<Team-Member-1>>  |
    |           |                   |
    |  <<Team-2>> | PO: <<Name>> | <<Teilprodukt-B>>
    |           |<<Team-Member-1>>  |
    |           |<<Team-Member-2>>  |
    |           |                   |
    |===

    <<<<
    [[Roadmaps]]
    == Roadmaps

    [role="req42help"]
    ****
    .Inhalt
    "Lieferobjekte auf die Zeitleiste gelegt" – wer liefert wann was?

    .Motivation
    Auch agile Projekte brauchen einen Plan. Je weiter ein Ziel in der Ferne liegt, desto ungenauer kann der Plan sein. Je näher, desto genauer.
    Eine explizit bekannte Roadmap ermöglicht allen Beteiligten sich untereinander abzustimmen und mitzudenken und daher bei kurzfristigen Entscheidungen zu berücksichtigen, was da mittelfristig noch alles kommen wird.
    Wenn Sie nur von der Hand in den Mund leben, treffen Sie unter Umständen unwissentlich kurzfristig Entscheidungen, die dem längerfristigen Produkterfolg entgegenstehen. In unseren Kursen zeigen wir Ihnen, wie grob oder fein eine Roadmap sein kann, darf oder sollte.

    .Notationen/Tools
    Was auch immer Sie als Planungswerkzeug im Einsatz haben oder was Ihnen erlaubt, möglichst auf einer Seite einen entsprechenden Überblick über einen längeren Zeitraum darzustellen.

    .Weiterführende Informationen

    Siehe https://docs.arc42.org/section-10/[Qualitätsanforderungen] in der online-Dokumentation (auf Englisch!).

    ****

    << Hier Planung einfügen>>



    <<<<
    [[section-Risiken-und-Annahmen]]
    == Risiken und Annahmen

    [role="req42help"]
    ****
    .Inhalt
    (Priorisierte) Listen von Risiken, die Sie erkannt haben und eine Liste von Annahmen, die Sie als Grundlage für Entscheidungen getroffen haben.

    .Motivation
    „Risikomanagement ist Projektmanagement für Erwachsene“  sagt Tim Lister von der Atlantic Systems Guild“.  In diesem Sinne sollten Sie Ihre Risiken als Product Owner im Griff halten.
    req42 gibt Ihnen die Mittel an die Hand, Risiken bewusst zu managen. Insbesondere beim Priorisierung Ihrer Anforderungen sollten Sie ausgewogen zwischen Business Value und Risk Reduction abwägen.

    .Notationen/Tools
    Einfache Tabellen oder Listen reichen oft bereits aus.


    .Weiterführende Informationen

    Siehe https://docs.arc42.org/section-11/[Risiken und technische Schulden] in der online-Dokumentation (auf Englisch!).
    ****

    === 12.1. Risiken
    [cols="1,3,1,1,3" options="header"]
    |===
    |Nr. |Text |Wahrscheinlichkeit |Schadenshöhe | Evtl. Maßnahmen
    | _<1>_ | _<Risiko-1>_ | _<%-1>_ | _<Höhe-1>_ |_<Maßnahme-1>_
    | _<2>_ | _<Risiko-2>_ | _<%2-2>_ | _<Höhe-2>_ |_<Maßnahme-1>_
    |===

    === 12.2. Annahmen
    [cols="1,5" options="header"]
    |===
    |Nr. |Text
    | _<1>_ | _<Annahme-1>_
    | _<2>_ | _<Annahme-2>_
    |===
