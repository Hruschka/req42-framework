# Qualitätsanforderungen

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Inhalt

</div>

Anforderungen an Qualitäten sind das "Wie" zum "Was" – qualitative
Definitionen oder Präzisierungen der funktionalen Anforderungen.

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Unsere Erfahrung zeigt: Qualitätsanforderungen sind (leider) nicht nur
in der agilen Welt immer noch heftig unterschätzt. Jeder will qualitativ
gute Produkte und Services, aber nur wenige machen es explizit, was
damit genau gemeint ist.

</div>

Einige Qualitätsanforderungen (wie Antwortzeiten) lassen sich vielleicht
direkt in eine Story integrieren (oder als Abnahmekriterium
dazuschreiben).

Die große Mehrheit an Qualitätsanforderungen bezieht sich jedoch auf
viele, wenn nicht sogar auf alle funktionalen Anforderungen des Product
Backlogs.

Deshalb brauchen Sie als Product Owner irgendwo die Möglichkeit, die
gewünschten Qualitäten Ihrer Produkte und Services zu spezifizieren und
zuzuweisen. Für diese Tätigkeit stehen Ihnen industrie-erprobten
Checklisten (wie Q42, ISO 25010 und andere) zur Verfügung, welche Ihnen
helfen, rasch die wichtigsten Kategorien zu identifizieren und managen
zu können.

<div class="formalpara">

<div class="title">

Notationen/Tools

</div>

Einfache textuelle Szenarien, evtl. nach den Kapiteln des ISO 25010
Qualitätsbaums oder nach VOLERE gegliedert.

</div>

</div>

*\<Text Qualitätsanforderungen bzw. -Szenario 1\>* : *\<Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich\>*

*\<Text Qualitätsanforderungen bzw. -Szenario 2\>* : *\<Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich\>*

*\<Text Qualitätsanforderungen bzw. -Szenario 3\>* : *\<Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich\>* . . . *\<Text
Qualitätsanforderungen bzw. -Szenario n\>* : *\<Link auf funktionale
Anforderungen bzw. Gültigkeitsbereich\>*
