# Visionen und Ziele

<div class="formalpara-title">

**Inhalt**

</div>

Die Business-Ziele Ihrer Produktentwicklung bzw. Ihres Projekts.
Stakeholder-verständlich und transparent.

<div class="formalpara-title">

**Motivation**

</div>

Die Ziele müssen so weit präzisiert und abgestimmt werden, dass alle
Beteiligten eine klare Vorstellung davon haben, was in welchen
Zeiträumen erreicht werden soll. Die Festlegung von Visionen und Zielen
leitet das Team bei der Ausarbeitung der detaillierten Anforderungen und
vermeidet Verzettelung. Vielleicht haben Ihnen Ihre Auftraggeber grobe
Ziele oder eine Vision mitgegeben, als man Sie mit der Rolle des Product
Owners betraut hat. Oft reicht jedoch die Präzision dieser Vorgaben
nicht aus, um ein Team systematisch zum Erfolg zu führen. Für uns gilt:
Ziele sind Anforderungen! Oder präziser: Ziele sind die Anforderungen,
die sich hoffentlich in dem Zeitraum, für den sie definiert werden,
stabil bleiben.

<div class="formalpara-title">

**Form**

</div>

Zur Definition von Zielen stehen Ihnen verschiedenste Ausdrucksmittel
zur Verfügung, die Sie nach Lust und Laune wählen können. Unsere
Empfehlung: \* Notation in Form von PAM (Purpose, Advantage, Metric)
Alternative Notationsformen: \* Produktkoffer \* News from the Future \*
Product Canvas \* Value Proposition Nur eines sollten Sie nie machen:
Ohne explizite Ziele oder Visionen zu arbeiten.

Siehe [Anforderungen und Ziele](https://docs.arc42.org/section-1/) in
der online-Dokumentation (auf Englisch!).

Zieldefinitionen nach PAM:

Ziel 1: Vorteil 1: Metrik 1:

Ziel 2: Vorteil 2: Metrik 2:

Ziel 3: Vorteil 3: Metrik 3:
