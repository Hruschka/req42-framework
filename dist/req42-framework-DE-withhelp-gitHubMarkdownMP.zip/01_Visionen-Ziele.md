# Visionen und Ziele

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Inhalt

</div>

Die Business-Ziele Ihrer Produktentwicklung bzw. Ihres Projekts.
Stakeholder-verständlich und transparent.

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Die Ziele müssen so weit präzisiert und abgestimmt werden, dass alle
Beteiligten eine klare Vorstellung davon haben, was in welchen
Zeiträumen erreicht werden soll.

</div>

Die Festlegung von Visionen und Zielen leitet das Team bei der
Ausarbeitung der detaillierten Anforderungen und vermeidet Verzettelung.

Vielleicht haben Ihnen Ihre Auftraggeber grobe Ziele oder eine Vision
mitgegeben, als man Sie mit der Rolle des Product Owners betraut hat.
Oft reicht jedoch die Präzision dieser Vorgaben nicht aus, um ein Team
systematisch zum Erfolg zu führen.

Für uns gilt: Ziele sind Anforderungen! Oder präziser: Ziele sind die
Anforderungen, die sich hoffentlich in dem Zeitraum, für den sie
definiert werden, stabil bleiben.

<div class="formalpara">

<div class="title">

Form

</div>

Zur Definition von Zielen stehen Ihnen verschiedenste Ausdrucksmittel
zur Verfügung, die Sie nach Lust und Laune wählen können.

</div>

Unsere Empfehlung:

- Notation in Form von PAM (Purpose, Advantage, Metric)

Alternative Notationsformen:

- Produktkoffer

- News from the Future

- Product Canvas

- Value Proposition

Nur eines sollten Sie nie machen: Ohne explizite Ziele oder Visionen zu
arbeiten.

</div>

Zieldefinitionen nach PAM:

Ziel 1:

Vorteil 1:

Metrik 1:

Ziel 2:

Vorteil 2:

Metrik 2:

Ziel 3:

Vorteil 3:

Metrik 3:
