# Randbedingungen

<div class="formalpara-title">

**Inhalt**

</div>

Technologische oder organisatorische Randbedingungen, bzw.
Randbedingungen für den Entwicklungsprozess, wie verpflichtende
Tätigkeiten, vorgeschriebene Dokumente und deren Inhalt, einzuhaltenden
Meilensteine, …

<div class="formalpara-title">

**Motivation**

</div>

Auch solche Randbedingungen sind Anforderungen. Und da sie oft für
mehrere oder sogar alle funktionalen Anforderungen gelten, sind sie
schwer in dem geordneten Product Backlog unterzubringen. Stellen Sie
einfach sicher, dass alle Beteiligten diese Randbedingungen kennen und
bei Bedarf Zugriff dazu haben.

<div class="formalpara-title">

**Notationen/Tools**

</div>

Einfache Listen, evtl. nach Kategorien geordnet.

## 7.1 Organisatorische Randbedingungen

\* \* \*

## 7.2 Technische Randbedingungen

\* \* \*
