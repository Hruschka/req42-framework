# Randbedingungen

<div class="formalpara-title">

**Inhalt**

</div>

Technologische oder organisatorische Randbedingungen, bzw.
Randbedingungen für den Entwicklungsprozess, wie verpflichtende
Tätigkeiten, vorgeschriebene Dokumente und deren Inhalt, einzuhaltenden
Meilensteine, …

<div class="formalpara-title">

**Motivation**

</div>

Auch solche Randbedingungen sind Anforderungen. Und da sie oft für
mehrere oder sogar alle funktionalen Anforderungen gelten, sind sie
schwer in dem geordneten Product Backlog unterzubringen. Stellen Sie
einfach sicher, dass alle Beteiligten diese Randbedingungen kennen und
bei Bedarf Zugriff dazu haben.

<div class="formalpara-title">

**Notationen/Tools**

</div>

Einfache Listen, evtl. nach Kategorien geordnet.

Siehe [Architekturentscheidungen](https://docs.arc42.org/section-9/) in
der arc42 Dokumentation (auf Englisch!). Dort finden Sie Links und
Beispiele zum Thema ADR.

## Organisatorische Randbedingungen

-   .

-   .

-   .

## Technische Randbedingungen

-   .

-   .

-   .
