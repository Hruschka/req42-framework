# Randbedingungen

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Inhalt

</div>

Technologische oder organisatorische Randbedingungen, bzw.
Randbedingungen für den Entwicklungsprozess, wie verpflichtende
Tätigkeiten, vorgeschriebene Dokumente und deren Inhalt, einzuhaltenden
Meilensteine, …​

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Auch solche Randbedingungen sind Anforderungen. Und da sie oft für
mehrere oder sogar alle funktionalen Anforderungen gelten, sind sie
schwer in dem geordneten Product Backlog unterzubringen. Stellen Sie
einfach sicher, dass alle Beteiligten diese Randbedingungen kennen und
bei Bedarf Zugriff dazu haben.

</div>

<div class="formalpara">

<div class="title">

Notationen/Tools

</div>

Einfache Listen, evtl. nach Kategorien geordnet.

</div>

</div>

## Organisatorische Randbedingungen

\* \* \*

## Technische Randbedingungen

\* \* \*
