# Domänenbegriffe

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Inhalt

</div>

Ein Glossar von fachlichen Begriffen mit Definitionen.

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

In jedem Epic, Feature oder Story kommen Begriffe aus Ihrer Domäne vor.
Diese Begriffe sollten allen Beteiligten klar sein. Und deshalb ist es
wünschenswert, für ein Projekt oder eine Produktentwicklung ein Glossar
solcher Begriffe zu haben.

</div>

Stellen Sie sicher, dass alle Beteiligten eine gemeinsame Sprache
sprechen – und im Zweifelsfall Zugriff auf vereinbarte
Begriffsdefinitionen haben, statt in jedem Meeting wieder neue Wörter
ins Spiel zu bringen.

<div class="formalpara">

<div class="title">

Notationen/Tools

</div>

Alphabetisch geordnete Liste von Begriffsdefinitionen

</div>

</div>

| Bedeutung       | Erläuterung         |
|-----------------|---------------------|
| *\<Begriff-1\>* | *\<Erläuterung-1\>* |
| *\<Begriff-2\>* | *\<Erläuterung-2\>* |
