# Roadmaps

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Inhalt

</div>

"Liefergegenstände auf die Zeitleiste gelegt" – wer liefert wann was?

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Auch agile Projekte brauchen einen Plan. Je weiter ein Ziel in der Ferne
liegt, desto ungenauer kann der Plan sein. Je näher, desto genauer. Eine
explizit bekannte Roadmap ermöglicht allen Beteiligten sich
untereinander abzustimmen und mitzudenken und daher bei kurzfristigen
Entscheidungen zu berücksichtigen, was da mittelfristig noch alles
kommen wird.

</div>

Wenn Sie nur von der Hand in den Mund leben, treffen Sie unter Umständen
unwissentlich kurzfristig Entscheidungen, die dem längerfristigen
Produkterfolg entgegenstehen. In unseren Kursen zeigen wir Ihnen, wie
grob oder fein eine Roadmap sein kann, darf oder sollte.

<div class="formalpara">

<div class="title">

Notationen/Tools

</div>

Was auch immer Sie als Planungswerkzeug im Einsatz haben oder was Ihnen
erlaubt, möglichst auf einer Seite einen entsprechenden Überblick über
einen längeren Zeitraum darzustellen.

</div>

</div>

*\< Hier Ihre Planung einfügen \>*
