# Stakeholder

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Role</th>
<th style="text-align: left;">Person</th>
<th style="text-align: left;">Topic</th>
<th style="text-align: left;">Influence</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Topic-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Influence-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Topic-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Influence-2&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
