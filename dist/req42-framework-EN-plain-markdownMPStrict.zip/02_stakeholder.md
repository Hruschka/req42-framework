# Stakeholder

**Content**

A (prioritized) list of your stakeholders, along with indications of
where these stakeholders can help (or hinder) the analysis work.

**Motivation**

Stakeholders are the most important sources for requirements. Therefore,
you should know and document them. You need to know who can help you
with what or hinder you in what way. You need to know who has what
influence - and if opinions differ, you need to mediate or decide.
Without explicitly identified stakeholders, all this is difficult.

-   Tables or lists (simple form)

-   Possibly stakeholder map (more complex form)

Below we have included a simple stakeholder list as an example.

The order "role before person" has been chosen deliberately. This order
has proven itself since requirements normally always represent needs
from the perspective of a role, but the person taking on the role can
change during the project.

If required, you can also add further columns (contact data, …) - but
consider the effort for their maintenance.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Role</th>
<th style="text-align: left;">Person</th>
<th style="text-align: left;">Topic</th>
<th style="text-align: left;">Influence</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Topic-1&gt;</em></p></td>
<td style="text-align: left;"><p>_&lt;Influence-1&gt;</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Topic-2&gt;</em></p></td>
<td style="text-align: left;"><p>_&lt;Influence-2&gt;</p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
