# Roadmap

**Content**

"Delivery objects put on the timeline" - who delivers what and when?

**Motivation**

Agile projects also need a plan. The more distant a goal is, the less
precise the plan can be. The closer, the more precise. An explicitly
known roadmap enables all participants to coordinate with each other and
to think along with each other, and therefore to take into account what
is still to come in the medium term when making short-term decisions. If
you only live from hand to mouth, you may unknowingly make short-term
decisions that are contrary to longer-term product success. In our
courses we show you how rough or fine a roadmap can, may or should be.

**Notations/Tools**

Whatever you have in use as a planning tool or which allows you to
present, if possible on one page, an appropriate overview over a longer
period of time.

Siehe [Risiken und technische
Schulden](https://docs.arc42.org/section-11/) in der
online-Dokumentation (auf Englisch!).

&lt;&lt; Insert planning here>&gt;
