# Constraints

## Organizational Constraints

- *&lt;OrgConstraint1&gt;*

- *&lt;OrgConstraint2&gt;*

- *&lt;OrgContraint3&gt;*

## Technical Constraints

- *&lt;TechConstraint1&gt;*

- *&lt;TechConstraint2&gt;*

- *&lt;TechContraint3&gt;*
