# Teams

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Team</th>
<th style="text-align: left;">Team Members</th>
<th style="text-align: left;">Feature</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Team-1&gt;</em></p></td>
<td style="text-align: left;"><p>PO: <em>&lt;Person-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Feature-A&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team member-2&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team member-3&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Team-2&gt;</em></p></td>
<td style="text-align: left;"><p>PO: <em>&lt;Person-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Feature-B&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team member-2&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
