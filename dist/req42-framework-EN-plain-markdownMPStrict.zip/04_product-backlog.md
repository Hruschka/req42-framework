# Product Backlog

EPIC 1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

FEATURE 1.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 1.1.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 1.1.x.:As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

EPIC 2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

FEATURE 2.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.1.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.1.2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

FEATURE 2.2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.2.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.2.2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

EPIC 3: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.
