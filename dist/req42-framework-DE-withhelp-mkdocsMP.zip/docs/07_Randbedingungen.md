# Randbedingungen {#section-Randbedingungen}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Inhalt

</div>

Technologische oder organisatorische Randbedingungen, bzw. Randbedingungen für den Entwicklungsprozess, wie verpflichtende Tätigkeiten, vorgeschriebene Dokumente und deren Inhalt, einzuhaltenden Meilensteine, …​

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Auch solche Randbedingungen sind Anforderungen. Und da sie oft für mehrere oder sogar alle funktionalen Anforderungen gelten, sind sie schwer in dem geordneten Product Backlog unterzubringen. Stellen Sie einfach sicher, dass alle Beteiligten diese Randbedingungen kennen und bei Bedarf Zugriff dazu haben.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notationen/Tools

</div>

Einfache Listen, evtl. nach Kategorien geordnet.

</div>

</div>

## Organisatorische Randbedingungen {#_organisatorische_randbedingungen}

\* \* \*

## Technische Randbedingungen {#_technische_randbedingungen}

\* \* \*

  [Randbedingungen]: #section-Randbedingungen {#toc-section-Randbedingungen}
  [Organisatorische Randbedingungen]: #_organisatorische_randbedingungen {#toc-_organisatorische_randbedingungen}
  [Technische Randbedingungen]: #_technische_randbedingungen {#toc-_technische_randbedingungen}
