# Scope-Abgrenzung {#section-Scope-Abgrenzung}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Inhalt

</div>

Ihr Produkt mit allen externen Schnittstellen zu (menschlichen und automatisierten) Nachbarn, bzw. Nachbarsystemen

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Scope ist der Bereich, den Sie beeinflussen können. Die Umgebung des Produktes, zu dem es sicherlich viele Schnittstellen gibt stellt den Kontext dar. Der Kontext kann (normalerweise) nicht von Ihnen allein entschieden werden, kann aber oft verhandeln werden. Um Klarheit zu gewinnen ist es wichtig beides möglichst zu beschreiben und vor allem die Grenze zwischen den beiden Bereichen zu definieren. req42 empfiehlt Ihnen mit dem Business-Scope zu beginnen und nicht zu früh den Product-Scope einzuschränken.

</div>

Die Entscheidung über die Produktgrenze sollte eine bewusste Entscheidung sein. Mehr über dieses unverzichtbare Thema lesen Sie im Blog-Beitrag „Scope ist nicht gleich Scope“. In unseren Kursen üben Sie die Scope-Abgrenzung anhand einer realistischen Fallstudie.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notationen/Tools

</div>

Zur Darstellung der Scope-Abgrenzung gibt es viele verschiedene Ausdrucksmittel, aber eine gute Scope-Abgrenzung macht die Schnittstellen zum Kontext explizit (z.B. in Form von Ein- und Ausgaben, von angebotenen und benötigten Services, …​)

</div>

- Diverse Formen von Kontextdiagrammen

- Kontexttabelle

</div>

*&lt;Kontextdiagramm&gt;* oder *&lt;Kontexttabelle&gt;* hier einfügen.

Optional: Tabelle mit Erläuterungen der Schnittstellen ergänzen:

| Bedeutung      | Erläuterung             |
|----------------|-------------------------|
| *&lt;IF-1&gt;* | *&lt;Erläuterung-1&gt;* |
| *&lt;IF-2&gt;* | *&lt;Erläuterung-2&gt;* |

  [Scope-Abgrenzung]: #section-Scope-Abgrenzung {#toc-section-Scope-Abgrenzung}
