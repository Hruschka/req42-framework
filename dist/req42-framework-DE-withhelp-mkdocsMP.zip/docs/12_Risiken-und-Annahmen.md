# Risiken und Annahmen {#section-Risiken-und-Annahmen}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Inhalt

</div>

(Priorisierte) Listen von Risiken, die Sie erkannt haben und eine Liste von Annahmen, die Sie als Grundlage für Entscheidungen getroffen haben.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

„Risikomanagement ist Projektmanagement für Erwachsene“ sagt Tim Lister von der Atlantic Systems Guild“. In diesem Sinne sollten Sie Ihre Risiken als Product Owner im Griff halten.

</div>

req42 gibt Ihnen die Mittel an die Hand, Risiken bewusst zu managen. Insbesondere beim Priorisieren Ihrer Anforderungen sollten Sie ausgewogen zwischen Business Value und Risk Reduction abwägen.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notationen/Tools

</div>

Einfache Tabellen oder Listen reichen oft bereits aus.

</div>

</div>

## Risiken {#_risiken}

| Nr. | Text | Wahrschein-lichkeit | Schadens-höhe | Evtl. Maßnahmen |
|-------|---------------------------|-------|-------|---------------------------|
| *1* | *&lt;Risiko-1&gt;* | *&lt;%-1&gt;* | *&lt;Höhe-1&gt;* | *&lt;Maßnahme-1&gt;* |
| *2* | *&lt;Risiko-2&gt;* | *&lt;%-2&gt;* | *&lt;Höhe-2&gt;* | *&lt;Maßnahme-1&gt;* |

## Annahmen {#_annahmen}

| Nr. | Text                |
|-----|---------------------|
| *1* | *&lt;Annahme-1&gt;* |
| *2* | *&lt;Annahme-2&gt;* |

  [Risiken und Annahmen]: #section-Risiken-und-Annahmen {#toc-section-Risiken-und-Annahmen}
  [Risiken]: #_risiken {#toc-_risiken}
  [Annahmen]: #_annahmen {#toc-_annahmen}
