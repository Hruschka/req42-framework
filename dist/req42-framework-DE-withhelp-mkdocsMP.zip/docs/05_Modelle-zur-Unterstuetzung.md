# Modelle zur Unterstützung {#section-Modelle-zur-Unterstuetzung}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Inhalt

</div>

Jegliche Art von grafischen Modellen, die das Verständnis (von Zusammenhängen) von Backlog Items erleichtern. Die Diagramme sollten mit Items aus dem Product Backlog verlinkt sein.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

In der agilen Welt hat es sich weit verbreitet, Anforderungen in Form von Epics, Features oder User Storys auf Kärtchen zu schreiben oder in äquivalenter Form in Tools abzulegen.

</div>

Trotzdem wird die Kommunikation unter allen Beteiligten manchmal erheblich einfacher, wenn man zusätzlich auch die Hilfsmittel verwendet, die wir in den letzten Jahrzehnten zur Präzisierung der Umgangssprache kennengelernt haben. Scheuen Sie also nicht davor zurück Modelle zu verwenden, wenn sie die Kommunikation fördern.

Keine Angst: diese Modelle müssen nicht perfekt sein. Aber insbesondere mit anwachsender Komplexität (Schleifen oder Fallunterscheidungen) fördert eine grafische Visualisierung der Schritte eines Geschäftsprozesses das Verständnis besser als viele Tickets im System ohne erkennbare Abfolgen und Abhängigkeiten.

<div markdown="1">

<div class="title" markdown="1">

Notationen/Tools

</div>

- Flussdiagramme

- Aktivitätsdiagramme

- BPMN

- Zustandsmodelle

- Datenmodelle

- UI-Prototypen

- Mock-ups

- Wireframes

</div>

Einfache Modellierungstools wie Gliffy, Diagrams.Net (früher DrawIO), …​…​, oder DSLs wie PlantUML, Kroki, …​ oder UML-Modellierungstools wie Enterprise Architect, Visual Paradigm, MagicDraw eignen sich zum Erstellen der Modelle. Die Modelle sollten mit Ihren Backlog-Items verlinkt sein (in beide Richtungen)

</div>

*&lt;Diagrammtitel 1:&gt;*. *&lt;hier Diagramm und evtl. Erläuterungen einfügen&gt;* *&lt;optional: Link zu Epics, Features oder Storys&gt;*

*&lt;Diagrammtitel 2:&gt;*. *&lt;hier Diagramm und evtl. Erläuterungen einfügen&gt;* *&lt;optional: Link zu Epics, Features oder Storys&gt;*

*&lt;Diagrammtitel 3:&gt;*. *&lt;hier Diagramm und evtl. Erläuterungen einfügen&gt;* *&lt;optional: Link zu Epics, Features oder Storys&gt;*

    .
    .
    .

*&lt;Diagrammtitel n:&gt;*. *&lt;hier Diagramm und evtl. Erläuterungen einfügen&gt;* *&lt;optional: Link zu Epics, Features oder Storys&gt;*

  [Modelle zur Unterstützung]: #section-Modelle-zur-Unterstuetzung {#toc-section-Modelle-zur-Unterstuetzung}
