# Teamstruktur {#section-Teamstruktur}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Inhalt

</div>

Bei kleinen Produktentwicklungen mit nur einem Entwicklungsteam kann dieser Abschnitt entfallen, da die Teammitglieder bereits im vorherigen Abschnitt aufgeführt sind. Bei skalierten großen Produkten sollte hier das Organigramm Ihrer Teams stehen und eine Zuordnung zu den Themen (z.B. Epics, Features, …​), für die dieses Team zuständig ist.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Wenn Sie über mehrere Teams verfügen, ist es selbstverständlich, dass Sie einen Überblick darüber haben, wer in welchem (Sub-)Team arbeitet und wie diese Teams organisiert sind.

</div>

Der Fokus sollte darauf liegen, dass die (Teil-)Teams so organisiert sind, dass sie möglichst selbstständig Funktionen/Features oder Teilprodukte liefern können, ohne sich ständig mit allen anderen abstimmen zu müssen.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notationen/Tools

</div>

Listen von Teams (jeweils mit zugewiesenen Personen und zugewiesenen Themen aus der Roadmap oder aus dem Product Backlog (z. B. Epics oder Features).

</div>

</div>

| Team             | Team-Mitglied           | Themen                  |
|------------------|-------------------------|-------------------------|
| *&lt;Team-1&gt;* | PO: *&lt;Name&gt;*      | *&lt;Teilprodukt-A&gt;* |
|                  | *&lt;Team-Member-1&gt;* |                         |
|                  |                         |                         |
| *&lt;Team-2&gt;* | PO: *&lt;Name&gt;*      | *&lt;Teilprodukt-B&gt;* |
|                  | *&lt;Team-Member-1&gt;* |                         |
|                  | *&lt;Team-Member-2&gt;* |                         |
|                  |                         |                         |

  [Teamstruktur]: #section-Teamstruktur {#toc-section-Teamstruktur}
