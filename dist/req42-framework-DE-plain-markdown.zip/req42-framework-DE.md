---
date: September 2026
title: "![req42](images/REQ42-logo.png) Framework"
---

# 

**Über req42**

req42, das Framework zur Sammlung, Dokumentation und Kommunikation von
Anforderungen im agilen Umfeld.

Erstellt von Dr. Peter Hruschka, Markus Meuten und Mitwirkenden.

Template Revision: 2.0.1-DE (asciidoc-based), September 2026

© We acknowledge that this document uses material from the req42
architecture framework, <https://req42.de>

# Visionen und Ziele {#section-Visionen-Ziele}

Zieldefinitionen nach PAM:

Ziel 1:

Vorteil 1:

Metrik 1:

Ziel 2:

Vorteil 2:

Metrik 2:

Ziel 3:

Vorteil 3:

Metrik 3:

# Stakeholder {#section-Stakeholder}

+----------+------------+----------------------+----------------------+
| Rolle    | Person     | Thema                | Einfluss             |
+==========+============+======================+======================+
| *\<Ro    | *\<P       | *\<Thema-1\>*        | *\<Einfluss-1\>*     |
| lle-1\>* | erson-1\>* |                      |                      |
+----------+------------+----------------------+----------------------+
| *\<Ro    | *\<P       | *\<Thema-2\>*        | *\<Einfluss-2\>*     |
| lle-2\>* | erson-2\>* |                      |                      |
+----------+------------+----------------------+----------------------+

# Scope-Abgrenzung {#section-Scope-Abgrenzung}

*\<Kontextdiagramm\>* oder *\<Kontexttabelle\>* hier einfügen.

Optional: Tabelle mit Erläuterungen der Schnittstellen ergänzen:

+-----------------+-----------------------------------------------------+
| Bedeutung       | Erläuterung                                         |
+=================+=====================================================+
| *\<IF-1\>*      | *\<Erläuterung-1\>*                                 |
+-----------------+-----------------------------------------------------+
| *\<IF-2\>*      | *\<Erläuterung-2\>*                                 |
+-----------------+-----------------------------------------------------+

# Product Backlog {#section-Product-Backlog}

EPIC 1: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

FEATURE 1.1: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 1.1.1.: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 1.1.x.: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

EPIC 2: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

FEATURE 2.1: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 2.1.1.: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 2.1.2: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

FEATURE 2.2: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 2.2.1.: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 2.2.2: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

EPIC 3: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

# Modelle zur Unterstützung {#section-Modelle-zur-Unterstuetzung}

*\<Diagrammtitel 1:\>*. *\<hier Diagramm und evtl. Erläuterungen
einfügen\>* *\<optional: Link zu Epics, Features oder Storys\>*

*\<Diagrammtitel 2:\>*. *\<hier Diagramm und evtl. Erläuterungen
einfügen\>* *\<optional: Link zu Epics, Features oder Storys\>*

*\<Diagrammtitel 3:\>*. *\<hier Diagramm und evtl. Erläuterungen
einfügen\>* *\<optional: Link zu Epics, Features oder Storys\>*

    .
    .
    .

*\<Diagrammtitel n:\>*. *\<hier Diagramm und evtl. Erläuterungen
einfügen\>* *\<optional: Link zu Epics, Features oder Storys\>*

# Qualitätsanforderungen {#section-Qualitaetsanforderungen}

*\<Text Qualitätsanforderungen bzw. -Szenario 1\>* : *\<Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich\>*

*\<Text Qualitätsanforderungen bzw. -Szenario 2\>* : *\<Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich\>*

*\<Text Qualitätsanforderungen bzw. -Szenario 3\>* : *\<Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich\>* . . . *\<Text
Qualitätsanforderungen bzw. -Szenario n\>* : *\<Link auf funktionale
Anforderungen bzw. Gültigkeitsbereich\>*

# Randbedingungen {#section-Randbedingungen}

## Organisatorische Randbedingungen {#_organisatorische_randbedingungen}

\* \* \*

## Technische Randbedingungen {#_technische_randbedingungen}

\* \* \*

# Domänenbegriffe {#section-Domaenenbegriffe}

+-----------------+-----------------------------------------------------+
| Bedeutung       | Erläuterung                                         |
+=================+=====================================================+
| *\<Begriff-1\>* | *\<Erläuterung-1\>*                                 |
+-----------------+-----------------------------------------------------+
| *\<Begriff-2\>* | *\<Erläuterung-2\>*                                 |
+-----------------+-----------------------------------------------------+

# Betriebsmittel und Personal {#section-Betriebsmittel-und-Personal}

## Budget {#_budget}

(evtl. gegliedert nach Roadmap oder Zwischenzielen, bzw. aufgeteilt in
Personalbudget, Sachbudget, ...​)

## Zeitrahmen/Endtermin {#_zeitrahmenendtermin}

## Teammitglieder {#_teammitglieder}

(Aufzählung oder aber ein Link auf komplexe Teamstruktur in Abschnitt
10)

## Externe Ressourcen {#_externe_ressourcen}

# Teamstruktur {#section-Teamstruktur}

+-------------+---------------------------+---------------------------+
| Team        | Team-Mitglied             | Themen                    |
+=============+===========================+===========================+
| *           | PO: *\<Name\>*            | *\<Teilprodukt-A\>*       |
| \<Team-1\>* |                           |                           |
+-------------+---------------------------+---------------------------+
|             | *\<Team-Member-1\>*       |                           |
+-------------+---------------------------+---------------------------+
|             |                           |                           |
+-------------+---------------------------+---------------------------+
| *           | PO: *\<Name\>*            | *\<Teilprodukt-B\>*       |
| \<Team-2\>* |                           |                           |
+-------------+---------------------------+---------------------------+
|             | *\<Team-Member-1\>*       |                           |
+-------------+---------------------------+---------------------------+
|             | *\<Team-Member-2\>*       |                           |
+-------------+---------------------------+---------------------------+
|             |                           |                           |
+-------------+---------------------------+---------------------------+

# Roadmaps {#Roadmaps}

*\< Hier Ihre Planung einfügen \>*

# Risiken und Annahmen {#section-Risiken-und-Annahmen}

## Risiken {#_risiken}

+----+--------------------------+----+----+--------------------------+
| N  | Text                     | W  | S  | Evtl. Maßnahmen          |
| r. |                          | ah | ch |                          |
|    |                          | rs | ad |                          |
|    |                          | ch | en |                          |
|    |                          | ei | s- |                          |
|    |                          | n- | hö |                          |
|    |                          | li | he |                          |
|    |                          | ch |    |                          |
|    |                          | ke |    |                          |
|    |                          | it |    |                          |
+====+==========================+====+====+==========================+
| *  | *\<Risiko-1\>*           | *  | *\ | *\<Maßnahme-1\>*         |
| 1* |                          | \< | <H |                          |
|    |                          | %- | öh |                          |
|    |                          | 1\ | e- |                          |
|    |                          | >* | 1\ |                          |
|    |                          |    | >* |                          |
+----+--------------------------+----+----+--------------------------+
| *  | *\<Risiko-2\>*           | *  | *\ | *\<Maßnahme-1\>*         |
| 2* |                          | \< | <H |                          |
|    |                          | %- | öh |                          |
|    |                          | 2\ | e- |                          |
|    |                          | >* | 2\ |                          |
|    |                          |    | >* |                          |
+----+--------------------------+----+----+--------------------------+

## Annahmen {#_annahmen}

+-----+----------------------------------------------------------------+
| Nr. | Text                                                           |
+=====+================================================================+
| *1* | *\<Annahme-1\>*                                                |
+-----+----------------------------------------------------------------+
| *2* | *\<Annahme-2\>*                                                |
+-----+----------------------------------------------------------------+
