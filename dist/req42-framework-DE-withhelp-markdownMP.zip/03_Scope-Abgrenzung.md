# Scope-Abgrezung {#section-Scope-Abgrenzung}

::: formalpara-title
**Inhalt**
:::

Ihr Produkt mit allen externen Schnittstellen zu (menschlichen und
automatisierten) Nachbarn, bzw. Nachbarsystemen

::: formalpara-title
**Motivation**
:::

Scope ist der Bereich, den Sie beeinflussen können. Die Umgebung des
Produktes, zu dem es sicherlich viele Schnittstellen gibt stellt den
Kontext dar. Der Kontext kann (normalerweise) nicht von Ihnen allein
entschieden werden, kann aber oft verhandeln werden. Um Klarheit zu
gewinnen ist es wichtig beides möglichst zu beschreiben und vor allem
die Grenze zwischen den beiden Bereichen zu definieren. req42 empfiehlt
Ihnen mit dem Business-Scope zu beginnen und nicht zu früh den
Product-Scope einzuschränken.

Die Entscheidung über die Produktgrenze sollte eine bewusste
Entscheidung sein. Mehr über dieses unverzichtbare Thema lesen Sie im
Blog-Beitrag „Scope ist nicht gleich Scope". In unseren Kursen üben Sie
die Scope-Abgrenzung anhand einer realistischen Fallstudie.

::: formalpara-title
**Notationen/Tools**
:::

Zur Darstellung der Scope-Abgrenzung gibt es viele verschiedene
Ausdrucksmittel, aber eine gute Scope-Abgrenzung macht die
Schnittstellen zum Kontext explizit (z.B. in Form von Ein- und Ausgaben,
von angebotenen und benötigten Services, ...)

-   Diverse Formen von Kontextdiagrammen

-   Kontexttabelle

*\<Kontextdiagramm>* oder *\<Kontexttabelle>* hier einfügen.

Optional: Tabelle mit Erläuterungen der Schnittstellen ergänzen:

+-----------------+-----------------------------------------------------+
| Bedeutung       | Erläuterung                                         |
+=================+=====================================================+
| *\<IF-1>*       | *\<Erläuterung-1>*                                  |
+-----------------+-----------------------------------------------------+
| *\<IF-2>*       | *\<Erläuterung-2>*                                  |
+-----------------+-----------------------------------------------------+
