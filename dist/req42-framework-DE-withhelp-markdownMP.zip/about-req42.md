# 

**Über req42**

req42, das Framework zur Sammlung, Dokumentation und Kommunikation von
Anforderungen im agilen Umfeld.

Erstellt von Dr. Peter Hruschka, Markus Meuten und Mitwirkenden.

Template Revision: 2.0.1-DE (asciidoc-based), September 2026

© We acknowledge that this document uses material from the req42
architecture framework, <https://req42.de>
