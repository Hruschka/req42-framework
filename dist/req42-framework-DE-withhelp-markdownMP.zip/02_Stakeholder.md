# Stakeholder {#section-Stakeholder}

::: formalpara-title
**Inhalt**
:::

Eine (priorisierte) Liste Ihrer Stakeholder, zusammen Angaben, wo diese
Stakeholder bei der Analysearbeit helfen (oder hindern) können.

::: formalpara-title
**Motivation**
:::

Stakeholder sind die wichtigsten Quellen für Anforderungen. Deshalb
sollten Sie diese kennen und dokumentieren. Sie müssen wissen, wer davon
Ihnen wobei helfen oder Sie in welcher Form behindern kann. Sie müssen
wissen, wer welchen Einfluss hat -- und bei unterschiedlichen Meinungen
müssen Sie vermitteln oder entscheiden. Ohne explizit identifizierte
Stakeholder ist das alles schwierig.

-   Tabellen oder Listen (einfache Form)

-   Evtl. Stakeholder-Map (komplexere Form) Nachfolgend haben wir als
    Beispiel eine einfache Stakeholder-Liste eingefügt. Die Reihenfolge
    \"Rolle vor Person\" ist bewusst gewählt. Diese Reihenfolge hat sich
    bewährt da Anforderungen normalerweise immer Bedarfe aus Sicht einer
    Rolle darstellen, die Person, welche die Rolle einnimmt während des
    Projektes aber durchaus wechseln kann. Sie können bei Bedarf auch
    gerne weitere Spalten hinzufügen (Kontaktdaten, ...) -- bedenken Sie
    aber den Aufwand für deren Pflege.

Siehe [Kontextabgrenzung](https://docs.arc42.org/section-3/) in der
online-Dokumentation (auf Englisch!).

+----------+----------+-----------------------+-----------------------+
| Rolle    | Person   | Thema                 | Einfluss              |
+==========+==========+=======================+=======================+
| *\<R     | *\<Pe    | *\<Thema-1>*          | *\<Einfluss-1>*       |
| olle-1>* | rson-1>* |                       |                       |
+----------+----------+-----------------------+-----------------------+
| *\<R     | *\<Pe    | *\<Thema-2>*          | *\<Einfluss-2>*       |
| olle-2>* | rson-2>* |                       |                       |
+----------+----------+-----------------------+-----------------------+
