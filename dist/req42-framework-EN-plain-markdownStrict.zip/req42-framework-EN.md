# 

**About req42**

req42, the framework for collecting, documenting and communicating
requirements.

Created and maintained by Dr. Peter Hruschka, Markus Meuten and
contributors.

Template Revision: 2.0.2-EN (based on asciidoc), September 2026

© We acknowledge that this document uses material from the req42
framework, <https://req42.de>

# Business Goals

Goal definitions according to PAM:

Goal 1:

Advantage 1:

Metric 1:

Goal 2:

Advantage 2:

Metric 2:

Goal 3:

Advantage 3:

Metric 3:

# Stakeholder

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Role</th>
<th style="text-align: left;">Person</th>
<th style="text-align: left;">Topic</th>
<th style="text-align: left;">Influence</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Topic-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Influence-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Role-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Topic-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Influence-2&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

# Scope

Insert *&lt;Context diagram&gt;* or *&lt;Context table&gt;* here.

Optional: add table with explanations of interfaces:

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 83%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Interface Name</th>
<th style="text-align: left;">Meaning/Explanation</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;IF-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Meaning-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;IF-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Meaning-2&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

# Product Backlog

EPIC 1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

FEATURE 1.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 1.1.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 1.1.x.:As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

EPIC 2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

FEATURE 2.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.1.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.1.2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

FEATURE 2.2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.2.1: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

STORY 2.2.2: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

EPIC 3: As *&lt;role&gt;* I want *&lt;functionality&gt;* so that
*&lt;advantage&gt;*. *&lt;optional: Link to models&gt;*.

# Supporting Models

*&lt;Diagram Title 1:&gt;*. *&lt;insert diagram and explanations here
&gt;* *&lt;optional: Link to Epics, Features or Stories&gt;*

*&lt;Diagram Title 2:&gt;*. *&lt;insert diagram and explanations here
&gt;* *&lt;optional: Link to Epics, Features or Stories&gt;*

*&lt;Diagram Title 3:&gt;*. *&lt;insert diagram and explanations here
&gt;* *&lt;optional: Link to Epics, Features or Stories&gt;*

    .
    .
    .

*&lt;Diagram Title n:&gt;*. *&lt;insert diagram and explanations here
&gt;* *&lt;optional: Link to Epics, Features or Stories&gt;*

# Quality Requirements

*&lt; quality requirement or scenario 1&gt;* : *&lt;Link to functional
requirements or scope for this quality &gt;*

*&lt; quality requirement or scenario 2&gt;* : *&lt;Link to functional
requirements or scope for this quality &gt;*

*&lt; quality requirement or scenario 3&gt;* : *&lt;Link to functional
requirements or scope for this quality &gt;*

    .
    .
    .

*&lt; quality requirement or scenario n&gt;* : *&lt;Link to functional
requirements or scope for this quality &gt;*

# Constraints

## Organizational Constraints

- *&lt;OrgConstraint1&gt;*

- *&lt;OrgConstraint2&gt;*

- *&lt;OrgContraint3&gt;*

## Technical Constraints

- *&lt;TechConstraint1&gt;*

- *&lt;TechConstraint2&gt;*

- *&lt;TechContraint3&gt;*

# Domain Terminology

<table>
<colgroup>
<col style="width: 19%" />
<col style="width: 80%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Term</th>
<th style="text-align: left;">Definition</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Term-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Definition-1&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Term-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Definition-2&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

# Assets

## Budget

(possibly structured according to roadmap or intermediate goals, or
divided into personnel budget, material budget, …​)

## Time frame/final date

## Team members

(simple enumeration of team members for small team. Or a link to complex
team structure in section 10).

## External resources

# Teams

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Team</th>
<th style="text-align: left;">Team Members</th>
<th style="text-align: left;">Feature</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"><p><em>&lt;Team-1&gt;</em></p></td>
<td style="text-align: left;"><p>PO: <em>&lt;Person-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Feature-A&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team member-2&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team member-3&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"><p><em>&lt;Team-2&gt;</em></p></td>
<td style="text-align: left;"><p>PO: <em>&lt;Person-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Feature-B&gt;</em></p></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team member-2&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

# Roadmap

*&lt; Insert your planning here&gt;*

# Risks & Assumptions

## Risks

<table>
<colgroup>
<col style="width: 11%" />
<col style="width: 33%" />
<col style="width: 11%" />
<col style="width: 11%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Id</th>
<th style="text-align: left;">Text</th>
<th style="text-align: left;">Probability</th>
<th style="text-align: left;">Damage Amount</th>
<th style="text-align: left;">Possible Measures</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

## Assumptions

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 83%" />
</colgroup>
<thead>
<tr>
<th style="text-align: left;">Id</th>
<th style="text-align: left;">Text</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>
