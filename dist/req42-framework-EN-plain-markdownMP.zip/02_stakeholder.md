# Stakeholder {#section-stakeholder}

::: formalpara-title
**Content**
:::

A (prioritized) list of your stakeholders, along with indications of
where these stakeholders can help (or hinder) the analysis work.

::: formalpara-title
**Motivation**
:::

Stakeholders are the most important sources for requirements. Therefore,
you should know and document them. You need to know who can help you
with what or hinder you in what way. You need to know who has what
influence - and if opinions differ, you need to mediate or decide.
Without explicitly identified stakeholders, all this is difficult.

::: formalpara-title
**Notations/Tools**
:::

Einfache Tabellen der Randbedingungen mit Erläuterungen. Bei Bedarf
unterscheiden Sie technische, organisatorische und politische
Randbedingungen oder übergreifende Konventionen (beispielsweise
Programmier- oder Versionierungsrichtlinien, Dokumentations- oder
Namenskonvention).

-   Tables or lists (simple form)

-   Possibly stakeholder map (more complex form)

Below we have included a simple stakeholder list as an example.

The order \"role before person\" has been chosen deliberately. This
order has proven itself since requirements normally always represent
needs from the perspective of a role, but the person taking on the role
can change during the project. If required, you can also add further
columns (contact data, ...) - but consider the effort for their
maintenance.

Siehe [Randbedingungen](https://docs.arc42.org/section-2/) in der
online-Dokumentation (auf Englisch!).

+-------------+---------------------------+-------------+-------------+
| Role        | Person                    | Topic       | Influence   |
+=============+===========================+=============+=============+
| *\<Role-1>* | *\<Person-1>*             | *           | \_\<I       |
|             |                           | \<Topic-1>* | nfluence-1> |
+-------------+---------------------------+-------------+-------------+
| *\<Role-2>* | *\<Person-2>*             | *           | \_\<I       |
|             |                           | \<Topic-2>* | nfluence-2> |
+-------------+---------------------------+-------------+-------------+
|             |                           |             |             |
+-------------+---------------------------+-------------+-------------+
