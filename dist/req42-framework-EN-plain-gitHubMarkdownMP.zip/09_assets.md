# Assets

## Budget

(possibly structured according to roadmap or intermediate goals, or
divided into personnel budget, material budget, …​)

## Time frame/final date

## Team members

(simple enumeration of team members for small team. Or a link to complex
team structure in section 10).

## External resources
