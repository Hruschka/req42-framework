# Product Backlog

EPIC 1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

FEATURE 1.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 1.1.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 1.1.x.:As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

EPIC 2: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

FEATURE 2.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 2.1.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 2.1.2: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

FEATURE 2.2: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 2.2.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 2.2.2: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

EPIC 3: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.
