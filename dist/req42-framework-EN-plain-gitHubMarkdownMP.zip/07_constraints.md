# Constraints

<div class="formalpara-title">

**Content**

</div>

Technological or organizational (mandated) constraints for the
development process, such as mandatory activities, prescribed documents
and their content, milestones to be met, …

<div class="formalpara-title">

**Motivation**

</div>

Such constraints are also requirements. And since they often apply to
several or even all functional requirements, they are difficult to
accommodate in the ordered product backlog. Just make sure that all
stakeholders know these constraints and have access to them when needed.

<div class="formalpara-title">

**Form**

</div>

Simple lists, possibly organized by category.

## 7.1 Organizational Constraints

-   *\<OrgConstraint1>*

-   *\<OrgConstraint2>*

-   *\<OrgContraint3>*

## 7.2 Technical Constraints

-   *\<TechConstraint1>*

-   *\<TechConstraint2>*

-   *\<TechContraint3>*
