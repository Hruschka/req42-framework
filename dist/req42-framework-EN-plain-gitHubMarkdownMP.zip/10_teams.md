# Teams

| Team         | Team Members        | Feature         |
|--------------|---------------------|-----------------|
| *\<Team-1\>* | PO: *\<Person-1\>*  | *\<Feature-A\>* |
|              | *\<Team member-2\>* |                 |
|              | *\<Team member-3\>* |                 |
|              |                     |                 |
| *\<Team-2\>* | PO: *\<Person-2\>*  | *\<Feature-B\>* |
|              | *\<Team member-2\>* |                 |
|              |                     |                 |
