# Stakeholder

| Role         | Person         | Topic         | Influence         |
|--------------|----------------|---------------|-------------------|
| *\<Role-1\>* | *\<Person-1\>* | *\<Topic-1\>* | *\<Influence-1\>* |
| *\<Role-2\>* | *\<Person-2\>* | *\<Topic-2\>* | *\<Influence-2\>* |
|              |                |               |                   |
