# Risks & Assumptions

<div class="formalpara-title">

**Content**

</div>

(Prioritized) lists of risks you have identified and a list of
assumptions you have made as a basis for decisions.

<div class="formalpara-title">

**Motivation**

</div>

"Risk management is project management for adults" says Tim Lister of
the Atlantic Systems Guild".

With this in mind, you should keep your risks under control as a product
owner.

req42 provides you with the means to consciously manage risks.
Especially when prioritizing your requirements you should balance
business value and risk reduction.

<div class="formalpara-title">

**Notations/Tools**

</div>

Simple tables or lists are often already sufficient.

## 12.1. Risks

| Id                | Text | Probability | Damage Amount |
|-------------------|------|-------------|---------------|
| Possible Measures |      |             |               |
|                   |      |             |               |

## 12.2. Assumptions

| Id  | Text |
|-----|------|
|     |      |
|     |      |
