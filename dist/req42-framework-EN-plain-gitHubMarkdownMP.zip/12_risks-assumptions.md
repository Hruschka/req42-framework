# Risks & Assumptions

## Risks

| Id  | Text | Probability | Damage Amount | Possible Measures |
|-----|------|-------------|---------------|-------------------|
|     |      |             |               |                   |
|     |      |             |               |                   |

## Assumptions

| Id  | Text |
|-----|------|
|     |      |
|     |      |
