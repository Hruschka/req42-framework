# Scope

Insert *\<Context diagram\>* or *\<Context table\>* here.

Optional: add table with explanations of interfaces:

| Interface Name | Meaning/Explanation |
|----------------|---------------------|
| *\<IF-1\>*     | *\<Meaning-1\>*     |
| *\<IF-2\>*     | *\<Meaning-2\>*     |
|                |                     |
