---
date: September 2026
title: "![req42](images/REQ42-logo.png) Framework"
---

# 

**About req42**

req42, the framework for collecting, documenting and communicating
requirements.

Created and maintained by Dr. Peter Hruschka, Markus Meuten and
contributors.

Template Revision: 2.0.1-EN (based on asciidoc), September 2026

© We acknowledge that this document uses material from the req42
framework, <https://req42.de>

# Business Goals

Goal definitions according to PAM:

Goal 1:

Advantage 1:

Metric 1:

Goal 2:

Advantage 2:

Metric 2:

Goal 3:

Advantage 3:

Metric 3:

# Stakeholder

| Role         | Person         | Topic         | Influence         |
|--------------|----------------|---------------|-------------------|
| *\<Role-1\>* | *\<Person-1\>* | *\<Topic-1\>* | *\<Influence-1\>* |
| *\<Role-2\>* | *\<Person-2\>* | *\<Topic-2\>* | *\<Influence-2\>* |
|              |                |               |                   |

# Scope

Insert *\<Context diagram\>* or *\<Context table\>* here.

Optional: add table with explanations of interfaces:

| Interface Name | Meaning/Explanation |
|----------------|---------------------|
| *\<IF-1\>*     | *\<Meaning-1\>*     |
| *\<IF-2\>*     | *\<Meaning-2\>*     |
|                |                     |

# Product Backlog

EPIC 1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

FEATURE 1.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 1.1.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 1.1.x.:As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

EPIC 2: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

FEATURE 2.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 2.1.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 2.1.2: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

FEATURE 2.2: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 2.2.1: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

STORY 2.2.2: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

EPIC 3: As *\<role\>* I want *\<functionality\>* so that
*\<advantage\>*. *\<optional: Link to models\>*.

# Supporting Models

*\<Diagram Title 1:\>*. *\<insert diagram and explanations here \>*
*\<optional: Link to Epics, Features or Stories\>*

*\<Diagram Title 2:\>*. *\<insert diagram and explanations here \>*
*\<optional: Link to Epics, Features or Stories\>*

*\<Diagram Title 3:\>*. *\<insert diagram and explanations here \>*
*\<optional: Link to Epics, Features or Stories\>*

    .
    .
    .

*\<Diagram Title n:\>*. *\<insert diagram and explanations here \>*
*\<optional: Link to Epics, Features or Stories\>*

# Quality Requirements

*\< quality requirement or scenario 1\>* : *\<Link to functional
requirements or scope for this quality \>*

*\< quality requirement or scenario 2\>* : *\<Link to functional
requirements or scope for this quality \>*

*\< quality requirement or scenario 3\>* : *\<Link to functional
requirements or scope for this quality \>*

    .
    .
    .

*\< quality requirement or scenario n\>* : *\<Link to functional
requirements or scope for this quality \>*

# Constraints

## Organizational Constraints

- *\<OrgConstraint1\>*

- *\<OrgConstraint2\>*

- *\<OrgContraint3\>*

## Technical Constraints

- *\<TechConstraint1\>*

- *\<TechConstraint2\>*

- *\<TechContraint3\>*

# Domain Terminology

| Term         | Definition         |
|--------------|--------------------|
| *\<Term-1\>* | *\<Definition-1\>* |
| *\<Term-2\>* | *\<Definition-2\>* |
|              |                    |

# Assets

## Budget

(possibly structured according to roadmap or intermediate goals, or
divided into personnel budget, material budget, …​)

## Time frame/final date

## Team members

(simple enumeration of team members for small team. Or a link to complex
team structure in section 10).

## External resources

# Teams

| Team         | Team Members        | Feature         |
|--------------|---------------------|-----------------|
| *\<Team-1\>* | PO: *\<Person-1\>*  | *\<Feature-A\>* |
|              | *\<Team member-2\>* |                 |
|              | *\<Team member-3\>* |                 |
|              |                     |                 |
| *\<Team-2\>* | PO: *\<Person-2\>*  | *\<Feature-B\>* |
|              | *\<Team member-2\>* |                 |
|              |                     |                 |

# Roadmap

*\< Insert your planning here\>*

# Risks & Assumptions

## Risks

| Id  | Text | Probability | Damage Amount | Possible Measures |
|-----|------|-------------|---------------|-------------------|
|     |      |             |               |                   |
|     |      |             |               |                   |

## Assumptions

| Id  | Text |
|-----|------|
|     |      |
|     |      |
