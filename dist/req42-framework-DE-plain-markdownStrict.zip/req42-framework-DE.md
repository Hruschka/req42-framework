# 

**Über req42**

req42, das Framework zur Sammlung, Dokumentation und Kommunikation von
Anforderungen im agilen Umfeld.

Erstellt von Dr. Peter Hruschka, Markus Meuten und Mitwirkenden.

Template Revision: 2.0.1-DE (asciidoc-based), September 2026

© We acknowledge that this document uses material from the req42
architecture framework, <https://req42.de>

# Visionen und Ziele

Zieldefinitionen nach PAM:

Ziel 1:

Vorteil 1:

Metrik 1:

Ziel 2:

Vorteil 2:

Metrik 2:

Ziel 3:

Vorteil 3:

Metrik 3:

# Stakeholder

<table>
<colgroup>
<col style="width: 16%" />
<col style="width: 19%" />
<col style="width: 32%" />
<col style="width: 32%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Rolle</th>
<th style="text-align: left;">Person</th>
<th style="text-align: left;">Thema</th>
<th style="text-align: left;">Einfluss</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Rolle-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Thema-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Einfluss-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Rolle-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Person-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Thema-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Einfluss-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Scope-Abgrenzung

*&lt;Kontextdiagramm&gt;* oder *&lt;Kontexttabelle&gt;* hier einfügen.

Optional: Tabelle mit Erläuterungen der Schnittstellen ergänzen:

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 75%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Bedeutung</th>
<th style="text-align: left;">Erläuterung</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;IF-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;IF-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Product Backlog

EPIC 1: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;* damit
*&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

FEATURE 1.1: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 1.1.1.: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 1.1.x.: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

EPIC 2: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;* damit
*&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

FEATURE 2.1: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 2.1.1.: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 2.1.2: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

FEATURE 2.2: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 2.2.1.: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

STORY 2.2.2: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;*
damit *&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

EPIC 3: Als *&lt;Rolle&gt;* möchte ich *&lt;Funktionalität&gt;* damit
*&lt;Vorteil&gt;* *&lt;optional. Link zu Modellen&gt;*.

# Modelle zur Unterstützung

*&lt;Diagrammtitel 1:&gt;*. *&lt;hier Diagramm und evtl. Erläuterungen
einfügen&gt;* *&lt;optional: Link zu Epics, Features oder Storys&gt;*

*&lt;Diagrammtitel 2:&gt;*. *&lt;hier Diagramm und evtl. Erläuterungen
einfügen&gt;* *&lt;optional: Link zu Epics, Features oder Storys&gt;*

*&lt;Diagrammtitel 3:&gt;*. *&lt;hier Diagramm und evtl. Erläuterungen
einfügen&gt;* *&lt;optional: Link zu Epics, Features oder Storys&gt;*

    .
    .
    .

*&lt;Diagrammtitel n:&gt;*. *&lt;hier Diagramm und evtl. Erläuterungen
einfügen&gt;* *&lt;optional: Link zu Epics, Features oder Storys&gt;*

# Qualitätsanforderungen

*&lt;Text Qualitätsanforderungen bzw. -Szenario 1&gt;* : *&lt;Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich&gt;*

*&lt;Text Qualitätsanforderungen bzw. -Szenario 2&gt;* : *&lt;Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich&gt;*

*&lt;Text Qualitätsanforderungen bzw. -Szenario 3&gt;* : *&lt;Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich&gt;* . . . *&lt;Text
Qualitätsanforderungen bzw. -Szenario n&gt;* : *&lt;Link auf funktionale
Anforderungen bzw. Gültigkeitsbereich&gt;*

# Randbedingungen

## Organisatorische Randbedingungen

\* \* \*

## Technische Randbedingungen

\* \* \*

# Domänenbegriffe

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 75%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Bedeutung</th>
<th style="text-align: left;">Erläuterung</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Begriff-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Begriff-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Erläuterung-2&gt;</em></p></td>
</tr>
</tbody>
</table>

# Betriebsmittel und Personal

## Budget

(evtl. gegliedert nach Roadmap oder Zwischenzielen, bzw. aufgeteilt in
Personalbudget, Sachbudget, …​)

## Zeitrahmen/Endtermin

## Teammitglieder

(Aufzählung oder aber ein Link auf komplexe Teamstruktur in Abschnitt
10)

## Externe Ressourcen

# Teamstruktur

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Team</th>
<th style="text-align: left;">Team-Mitglied</th>
<th style="text-align: left;">Themen</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>&lt;Team-1&gt;</em></p></td>
<td style="text-align: left;"><p>PO: <em>&lt;Name&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Teilprodukt-A&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team-Member-1&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>&lt;Team-2&gt;</em></p></td>
<td style="text-align: left;"><p>PO: <em>&lt;Name&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Teilprodukt-B&gt;</em></p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team-Member-1&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"><p><em>&lt;Team-Member-2&gt;</em></p></td>
<td style="text-align: left;"></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

# Roadmaps

*&lt; Hier Ihre Planung einfügen &gt;*

# Risiken und Annahmen

## Risiken

<table style="width:100%;">
<colgroup>
<col style="width: 7%" />
<col style="width: 38%" />
<col style="width: 7%" />
<col style="width: 7%" />
<col style="width: 38%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Nr.</th>
<th style="text-align: left;">Text</th>
<th style="text-align: left;">Wahrschein-lichkeit</th>
<th style="text-align: left;">Schadens-höhe</th>
<th style="text-align: left;">Evtl. Maßnahmen</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>1</em></p></td>
<td style="text-align: left;"><p><em>&lt;Risiko-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;%-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Höhe-1&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Maßnahme-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>2</em></p></td>
<td style="text-align: left;"><p><em>&lt;Risiko-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;%-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Höhe-2&gt;</em></p></td>
<td style="text-align: left;"><p><em>&lt;Maßnahme-1&gt;</em></p></td>
</tr>
</tbody>
</table>

## Annahmen

<table>
<colgroup>
<col style="width: 9%" />
<col style="width: 90%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: left;">Nr.</th>
<th style="text-align: left;">Text</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><em>1</em></p></td>
<td style="text-align: left;"><p><em>&lt;Annahme-1&gt;</em></p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><em>2</em></p></td>
<td style="text-align: left;"><p><em>&lt;Annahme-2&gt;</em></p></td>
</tr>
</tbody>
</table>
