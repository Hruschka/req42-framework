=================
|req42| Framework
=================

:Date: September 2026

**Über req42**

req42, das Framework zur Sammlung, Dokumentation und Kommunikation von
Anforderungen im agilen Umfeld.

Erstellt von Dr. Peter Hruschka, Markus Meuten und Mitwirkenden.

Template Revision: 2.0.2-DE (asciidoc-based), September 2026

© We acknowledge that this document uses material from the req42
architecture framework, https://req42.de

.. _section-Visionen-Ziele:

Visionen und Ziele
==================

Zieldefinitionen nach PAM:

Ziel 1:

Vorteil 1:

Metrik 1:

Ziel 2:

Vorteil 2:

Metrik 2:

Ziel 3:

Vorteil 3:

Metrik 3:

.. _section-Stakeholder:

Stakeholder
===========

+-------------+--------------+----------------------+----------------------+
| Rolle       | Person       | Thema                | Einfluss             |
+=============+==============+======================+======================+
| *<Rolle-1>* | *<Person-1>* | *<Thema-1>*          | *<Einfluss-1>*       |
+-------------+--------------+----------------------+----------------------+
| *<Rolle-2>* | *<Person-2>* | *<Thema-2>*          | *<Einfluss-2>*       |
+-------------+--------------+----------------------+----------------------+

.. _section-Scope-Abgrenzung:

Scope-Abgrenzung
================

*<Kontextdiagramm>* oder *<Kontexttabelle>* hier einfügen.

Optional: Tabelle mit Erläuterungen der Schnittstellen ergänzen:

+-----------------+-----------------------------------------------------+
| Bedeutung       | Erläuterung                                         |
+=================+=====================================================+
| *<IF-1>*        | *<Erläuterung-1>*                                   |
+-----------------+-----------------------------------------------------+
| *<IF-2>*        | *<Erläuterung-2>*                                   |
+-----------------+-----------------------------------------------------+

.. _section-Product-Backlog:

Product Backlog
===============

EPIC 1: Als *<Rolle>* möchte ich *<Funktionalität>* damit *<Vorteil>*
*<optional. Link zu Modellen>*.

FEATURE 1.1: Als *<Rolle>* möchte ich *<Funktionalität>* damit
*<Vorteil>* *<optional. Link zu Modellen>*.

STORY 1.1.1.: Als *<Rolle>* möchte ich *<Funktionalität>* damit
*<Vorteil>* *<optional. Link zu Modellen>*.

STORY 1.1.x.: Als *<Rolle>* möchte ich *<Funktionalität>* damit
*<Vorteil>* *<optional. Link zu Modellen>*.

EPIC 2: Als *<Rolle>* möchte ich *<Funktionalität>* damit *<Vorteil>*
*<optional. Link zu Modellen>*.

FEATURE 2.1: Als *<Rolle>* möchte ich *<Funktionalität>* damit
*<Vorteil>* *<optional. Link zu Modellen>*.

STORY 2.1.1.: Als *<Rolle>* möchte ich *<Funktionalität>* damit
*<Vorteil>* *<optional. Link zu Modellen>*.

STORY 2.1.2: Als *<Rolle>* möchte ich *<Funktionalität>* damit
*<Vorteil>* *<optional. Link zu Modellen>*.

FEATURE 2.2: Als *<Rolle>* möchte ich *<Funktionalität>* damit
*<Vorteil>* *<optional. Link zu Modellen>*.

STORY 2.2.1.: Als *<Rolle>* möchte ich *<Funktionalität>* damit
*<Vorteil>* *<optional. Link zu Modellen>*.

STORY 2.2.2: Als *<Rolle>* möchte ich *<Funktionalität>* damit
*<Vorteil>* *<optional. Link zu Modellen>*.

EPIC 3: Als *<Rolle>* möchte ich *<Funktionalität>* damit *<Vorteil>*
*<optional. Link zu Modellen>*.

.. _section-Modelle-zur-Unterstuetzung:

Modelle zur Unterstützung
=========================

*<Diagrammtitel 1:>*. *<hier Diagramm und evtl. Erläuterungen einfügen>*
*<optional: Link zu Epics, Features oder Storys>*

*<Diagrammtitel 2:>*. *<hier Diagramm und evtl. Erläuterungen einfügen>*
*<optional: Link zu Epics, Features oder Storys>*

*<Diagrammtitel 3:>*. *<hier Diagramm und evtl. Erläuterungen einfügen>*
*<optional: Link zu Epics, Features oder Storys>*

::

   .
   .
   .

*<Diagrammtitel n:>*. *<hier Diagramm und evtl. Erläuterungen einfügen>*
*<optional: Link zu Epics, Features oder Storys>*

.. _section-Qualitaetsanforderungen:

Qualitätsanforderungen
======================

*<Text Qualitätsanforderungen bzw. -Szenario 1>* : *<Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich>*

*<Text Qualitätsanforderungen bzw. -Szenario 2>* : *<Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich>*

*<Text Qualitätsanforderungen bzw. -Szenario 3>* : *<Link auf
funktionale Anforderungen bzw. Gültigkeitsbereich>* . . . *<Text
Qualitätsanforderungen bzw. -Szenario n>* : *<Link auf funktionale
Anforderungen bzw. Gültigkeitsbereich>*

.. _section-Randbedingungen:

Randbedingungen
===============

.. _`_organisatorische_randbedingungen`:

Organisatorische Randbedingungen
--------------------------------

\* \* \*

.. _`_technische_randbedingungen`:

Technische Randbedingungen
--------------------------

\* \* \*

.. _section-Domaenenbegriffe:

Domänenbegriffe
===============

+-----------------+-----------------------------------------------------+
| Bedeutung       | Erläuterung                                         |
+=================+=====================================================+
| *<Begriff-1>*   | *<Erläuterung-1>*                                   |
+-----------------+-----------------------------------------------------+
| *<Begriff-2>*   | *<Erläuterung-2>*                                   |
+-----------------+-----------------------------------------------------+

.. _section-Betriebsmittel-und-Personal:

Betriebsmittel und Personal
===========================

.. _`_budget`:

Budget
------

(evtl. gegliedert nach Roadmap oder Zwischenzielen, bzw. aufgeteilt in
Personalbudget, Sachbudget, …​)

.. _`_zeitrahmenendtermin`:

Zeitrahmen/Endtermin
--------------------

.. _`_teammitglieder`:

Teammitglieder
--------------

(Aufzählung oder aber ein Link auf komplexe Teamstruktur in Abschnitt
10)

.. _`_externe_ressourcen`:

Externe Ressourcen
------------------

.. _section-Teamstruktur:

Teamstruktur
============

+-------------+---------------------------+---------------------------+
| Team        | Team-Mitglied             | Themen                    |
+=============+===========================+===========================+
| *<Team-1>*  | PO: *<Name>*              | *<Teilprodukt-A>*         |
+-------------+---------------------------+---------------------------+
|             | *<Team-Member-1>*         |                           |
+-------------+---------------------------+---------------------------+
|             |                           |                           |
+-------------+---------------------------+---------------------------+
| *<Team-2>*  | PO: *<Name>*              | *<Teilprodukt-B>*         |
+-------------+---------------------------+---------------------------+
|             | *<Team-Member-1>*         |                           |
+-------------+---------------------------+---------------------------+
|             | *<Team-Member-2>*         |                           |
+-------------+---------------------------+---------------------------+
|             |                           |                           |
+-------------+---------------------------+---------------------------+

.. _Roadmaps:

Roadmaps
========

*< Hier Ihre Planung einfügen >*

.. _section-Risiken-und-Annahmen:

Risiken und Annahmen
====================

.. _`_risiken`:

Risiken
-------

+-----+--------------------------+---------------------+---------------+--------------------------+
| Nr. | Text                     | Wahrschein-lichkeit | Schadens-höhe | Evtl. Maßnahmen          |
+=====+==========================+=====================+===============+==========================+
| *1* | *<Risiko-1>*             | *<%-1>*             | *<Höhe-1>*    | *<Maßnahme-1>*           |
+-----+--------------------------+---------------------+---------------+--------------------------+
| *2* | *<Risiko-2>*             | *<%-2>*             | *<Höhe-2>*    | *<Maßnahme-1>*           |
+-----+--------------------------+---------------------+---------------+--------------------------+

.. _`_annahmen`:

Annahmen
--------

+-----+----------------------------------------------------------------+
| Nr. | Text                                                           |
+=====+================================================================+
| *1* | *<Annahme-1>*                                                  |
+-----+----------------------------------------------------------------+
| *2* | *<Annahme-2>*                                                  |
+-----+----------------------------------------------------------------+

.. |req42| image:: images/REQ42-logo.png
