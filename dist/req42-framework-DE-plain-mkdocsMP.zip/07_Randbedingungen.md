# Randbedingungen {#section-Randbedingungen}

## Organisatorische Randbedingungen {#_organisatorische_randbedingungen}

\* \* \*

## Technische Randbedingungen {#_technische_randbedingungen}

\* \* \*
