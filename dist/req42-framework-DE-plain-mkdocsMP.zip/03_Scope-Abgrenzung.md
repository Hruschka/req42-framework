# Scope-Abgrenzung {#section-Scope-Abgrenzung}

*\<Kontextdiagramm\>* oder *\<Kontexttabelle\>* hier einfügen.

Optional: Tabelle mit Erläuterungen der Schnittstellen ergänzen:

+-----------------+-----------------------------------------------------+
| Bedeutung       | Erläuterung                                         |
+=================+=====================================================+
| *\<IF-1\>*      | *\<Erläuterung-1\>*                                 |
+-----------------+-----------------------------------------------------+
| *\<IF-2\>*      | *\<Erläuterung-2\>*                                 |
+-----------------+-----------------------------------------------------+
