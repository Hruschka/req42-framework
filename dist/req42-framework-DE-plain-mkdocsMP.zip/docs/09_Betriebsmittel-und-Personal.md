# Betriebsmittel und Personal {#section-Betriebsmittel-und-Personal}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Inhalt

</div>

Unter Betriebsmittel und Personal („Assets“) fassen wir das zusammen, was Ihnen Ihre Auftraggeber oder Chefs mitgeben, um Sie als Product Owner (zusammen mit Ihrem Team) zu befähigen, Ihren Job erfolgreich auszuführen.

</div>

Die Assets schließen auf jeden Fall Zeit und Budget ein, d.h. Mittel, die man Ihnen für Ihre Aufgabe zur Verfügung stellt. Vielleicht müssen Sie sich Ihr Team mit diesen Mitteln selbst besorgen oder man stellt Ihnen auch Personal (Ihr Team), Arbeitsräume, Infrastruktur, etc. zur Verfügung.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Wenn Sie den Job als Product Owner übernehmen, dann müssen Sie über diese Assets mit Ihren Auftraggebern verhandeln und sicherlich im Endeffekt über deren Verwendung auch (durch hoffentlich erfolgreiche Ergebnisse) Rechenschaft ablegen.

</div>

Auf jeden Fall sollten Sie wissen, was Ihnen an Geld, Personal, Zeit, Infrastruktur, …​ zur Verfügung steht. Diese Assets sind eine wesentliche Randbedingung für Ihre Arbeit als Product Owner.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notationen/Tools

</div>

Einfache Listen, Tabellen

</div>

</div>

## Budget {#_budget}

(evtl. gegliedert nach Roadmap oder Zwischenzielen, bzw. aufgeteilt in Personalbudget, Sachbudget, …​)

## Zeitrahmen/Endtermin {#_zeitrahmenendtermin}

## Teammitglieder {#_teammitglieder}

(Aufzählung oder aber ein Link auf komplexe Teamstruktur in Abschnitt 10)

## Externe Ressourcen {#_externe_ressourcen}

  [Betriebsmittel und Personal]: #section-Betriebsmittel-und-Personal {#toc-section-Betriebsmittel-und-Personal}
  [Budget]: #_budget {#toc-_budget}
  [Zeitrahmen/Endtermin]: #_zeitrahmenendtermin {#toc-_zeitrahmenendtermin}
  [Teammitglieder]: #_teammitglieder {#toc-_teammitglieder}
  [Externe Ressourcen]: #_externe_ressourcen {#toc-_externe_ressourcen}
