# Domänenbegriffe {#section-Domaenenbegriffe}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Inhalt

</div>

Ein Glossar von fachlichen Begriffen mit Definitionen.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

In jedem Epic, Feature oder Story kommen Begriffe aus Ihrer Domäne vor. Diese Begriffe sollten allen Beteiligten klar sein. Und deshalb ist es wünschenswert, für ein Projekt oder eine Produktentwicklung ein Glossar solcher Begriffe zu haben.

</div>

Stellen Sie sicher, dass alle Beteiligten eine gemeinsame Sprache sprechen – und im Zweifelsfall Zugriff auf vereinbarte Begriffsdefinitionen haben, statt in jedem Meeting wieder neue Wörter ins Spiel zu bringen.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notationen/Tools

</div>

Alphabetisch geordnete Liste von Begriffsdefinitionen

</div>

</div>

| Bedeutung           | Erläuterung             |
|---------------------|-------------------------|
| *&lt;Begriff-1&gt;* | *&lt;Erläuterung-1&gt;* |
| *&lt;Begriff-2&gt;* | *&lt;Erläuterung-2&gt;* |

  [Domänenbegriffe]: #section-Domaenenbegriffe {#toc-section-Domaenenbegriffe}
