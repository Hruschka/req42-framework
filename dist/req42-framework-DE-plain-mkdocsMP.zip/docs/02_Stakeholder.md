# Stakeholder {#section-Stakeholder}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Inhalt

</div>

Eine (priorisierte) Liste Ihrer Stakeholder, zusammen Angaben, wo diese Stakeholder bei der Analysearbeit helfen (oder hindern) können.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Stakeholder sind die wichtigsten Quellen für Anforderungen. Deshalb sollten Sie diese kennen und dokumentieren. Sie müssen wissen, wer davon Ihnen wobei helfen oder Sie in welcher Form behindern kann. Sie müssen wissen, wer welchen Einfluss hat – und bei unterschiedlichen Meinungen müssen Sie vermitteln oder entscheiden.

</div>

Ohne explizit identifizierte Stakeholder ist das alles schwierig.

<div markdown="1">

<div class="title" markdown="1">

Notationen/Tools

</div>

- Tabellen oder Listen (einfache Form)

- Evtl. Stakeholder-Map (komplexere Form)

</div>

Nachfolgend haben wir als Beispiel eine einfache Stakeholder-Liste eingefügt.

Die Reihenfolge "Rolle vor Person" ist bewusst gewählt. Diese Reihenfolge hat sich bewährt da Anforderungen normalerweise immer Bedarfe aus Sicht einer Rolle darstellen, die Person, welche die Rolle einnimmt während des Projektes aber durchaus wechseln kann.

Sie können bei Bedarf auch gerne weitere Spalten hinzufügen (Kontaktdaten, …) – bedenken Sie aber den Aufwand für deren Pflege.

</div>

| Rolle             | Person             | Thema             | Einfluss             |
|------------|--------------|-----------------------|-----------------------|
| *&lt;Rolle-1&gt;* | *&lt;Person-1&gt;* | *&lt;Thema-1&gt;* | *&lt;Einfluss-1&gt;* |
| *&lt;Rolle-2&gt;* | *&lt;Person-2&gt;* | *&lt;Thema-2&gt;* | *&lt;Einfluss-2&gt;* |

  [Stakeholder]: #section-Stakeholder {#toc-section-Stakeholder}
