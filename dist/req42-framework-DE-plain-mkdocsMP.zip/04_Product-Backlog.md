# Product Backlog {#section-Product-Backlog}

EPIC 1: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

FEATURE 1.1: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 1.1.1.: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 1.1.x.: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

EPIC 2: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

FEATURE 2.1: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 2.1.1.: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 2.1.2: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

FEATURE 2.2: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 2.2.1.: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

STORY 2.2.2: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.

EPIC 3: Als *\<Rolle\>* möchte ich *\<Funktionalität\>* damit
*\<Vorteil\>* *\<optional. Link zu Modellen\>*.
