# Betriebsmittel und Personal {#section-Betriebsmittel-und-Personal}

## Budget {#_budget}

(evtl. gegliedert nach Roadmap oder Zwischenzielen, bzw. aufgeteilt in
Personalbudget, Sachbudget, ...​)

## Zeitrahmen/Endtermin {#_zeitrahmenendtermin}

## Teammitglieder {#_teammitglieder}

(Aufzählung oder aber ein Link auf komplexe Teamstruktur in Abschnitt
10)

## Externe Ressourcen {#_externe_ressourcen}
