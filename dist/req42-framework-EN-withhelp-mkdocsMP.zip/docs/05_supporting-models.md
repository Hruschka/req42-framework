# Supporting Models {#section-suppporting-models}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

Any kind of graphical models that facilitate the understanding (of relationships) of Backlog Items. The diagrams should be linked to items from the Product Backlog.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

In the agile world, it has become widespread to write requirements in the form of epics, features or user stories on little cards or to file them in equivalent form in tools.

</div>

Nevertheless, communication among all stakeholders sometimes becomes much easier if you also use the tools we have come to know over the last decades to make the colloquial language more precise. So don’t be afraid to use models if they help communication.

Don’t worry: these models don’t have to be perfect. But especially with increasing complexity (loops or case distinctions), a graphical visualization of the steps of a business process promotes understanding better than many tickets in the system without recognizable sequences and dependencies.

<div markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

- Flowcharts

- activity diagrams

- BPMN

- state models

- data models

- UI prototypes

- mock-ups

- wireframes

</div>

Simple modeling tools like Gliffy, Diagrams.Net (formerly DrawIO), …​…​, or DSLs like PlantUML, Kroki, …​ or UML modeling tools like Enterprise Architect, Visual Paradigm, MagicDraw are suitable for creating the models. The models should be linked to your backlog items (in both directions)

</div>

*&lt;Diagram Title 1:&gt;*. *&lt;insert diagram and explanations here &gt;* *&lt;optional: Link to Epics, Features or Stories&gt;*

*&lt;Diagram Title 2:&gt;*. *&lt;insert diagram and explanations here &gt;* *&lt;optional: Link to Epics, Features or Stories&gt;*

*&lt;Diagram Title 3:&gt;*. *&lt;insert diagram and explanations here &gt;* *&lt;optional: Link to Epics, Features or Stories&gt;*

    .
    .
    .

*&lt;Diagram Title n:&gt;*. *&lt;insert diagram and explanations here &gt;* *&lt;optional: Link to Epics, Features or Stories&gt;*

  [Supporting Models]: #section-suppporting-models {#toc-section-suppporting-models}
