# Assets {#section-assets}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

Under assets we summarize everything that your sponsors or clients give you to enable you as a product owner (together with your team) to do your job successfully.

</div>

Assets definitely include time and budget, i.e., resources they give you to do your job. You may have to get your team with these resources yourself, or they may also provide you with staff (your team), workspace, infrastructure, etc.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

If you take on the job as a product owner you have to negotiate these assets with your sponsor or client and certainly in the end also account for their use (through hopefully successful results).

</div>

In any case, you should know what you have at your disposal in terms of money, personnel, time, infrastructure, …​ at your disposal. These assets are an essential boundary condition for your work as a product owner.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

Simple lists or tables

</div>

</div>

## Budget {#_budget}

(possibly structured according to roadmap or intermediate goals, or divided into personnel budget, material budget, …​)

## Time frame/final date {#_time_framefinal_date}

## Team members {#_team_members}

(simple enumeration of team members for small team. Or a link to complex team structure in section 10).

## External resources {#_external_resources}

  [Assets]: #section-assets {#toc-section-assets}
  [Budget]: #_budget {#toc-_budget}
  [Time frame/final date]: #_time_framefinal_date {#toc-_time_framefinal_date}
  [Team members]: #_team_members {#toc-_team_members}
  [External resources]: #_external_resources {#toc-_external_resources}
