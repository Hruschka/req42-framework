# Constraints {#section-constraints}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

Technological or organizational (mandated) constraints for the development process, such as mandatory activities, prescribed documents and their content, milestones to be met, …​

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Such constraints are also requirements. And since they often apply to several or even all functional requirements, they are difficult to accommodate in the ordered product backlog. Just make sure that all stakeholders know these constraints and have access to them when needed.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Form

</div>

Simple lists, possibly organized by category.

</div>

</div>

## Organizational Constraints {#_organizational_constraints}

- *&lt;OrgConstraint1&gt;*

- *&lt;OrgConstraint2&gt;*

- *&lt;OrgContraint3&gt;*

## Technical Constraints {#_technical_constraints}

- *&lt;TechConstraint1&gt;*

- *&lt;TechConstraint2&gt;*

- *&lt;TechContraint3&gt;*

  [Constraints]: #section-constraints {#toc-section-constraints}
  [Organizational Constraints]: #_organizational_constraints {#toc-_organizational_constraints}
  [Technical Constraints]: #_technical_constraints {#toc-_technical_constraints}
