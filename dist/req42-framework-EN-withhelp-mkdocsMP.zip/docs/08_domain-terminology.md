# Domain Terminology {#section-domain-terminology}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

A glossary of technical terms with definitions. The "ubiquitous language" of your domain

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Terms from your domain appear in every epic, feature, or story. These terms should be clear to everyone involved. And that’s why it is desirable to have a glossary of such terms for a project or product development.

</div>

Make sure that everyone involved speaks a common language - and has access to agreed-upon definitions of terms instead of bringing new words into play in every meeting.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

Alphabetically ordered list of term definitions

</div>

</div>

| Term             | Definition             |
|------------------|------------------------|
| *&lt;Term-1&gt;* | *&lt;Definition-1&gt;* |
| *&lt;Term-2&gt;* | *&lt;Definition-2&gt;* |
|                  |                        |

  [Domain Terminology]: #section-domain-terminology {#toc-section-domain-terminology}
