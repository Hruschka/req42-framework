**About req42**

req42, the framework for collecting, documenting and communicating requirements.

Created and maintained by Dr. Peter Hruschka, Markus Meuten and contributors.

Template Revision: 2.0 EN (based on asciidoc), March 2023

© We acknowledge that this document uses material from the req42 framework, <https://req42.de>

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="note" markdown="1">

<div class="title" markdown="1">

</div>

This version of the framework contains help texts and explanations. It is meant to familiarize yourself with the framework. For your own documentation better use the *plain* Version.

</div>

</div>

# Business Goals {#section-business-goals}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

The business objectives of your product development or project. Short and concise, understandable and transparent for your stakeholders.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Goals must be specified and agreed upon to the point where everyone involved has a clear idea of what is to be accomplished and in what time frames. Establishing vision and goals guides the team in developing detailed requirements and avoids fragmentation.

</div>

Perhaps your clients gave you rough goals or a vision when they entrusted you with the role of product owner. Often, however, the precision of these specifications is not enough to lead a team systematically to success.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

A wide variety of means of expression are available for defining goals, which you can choose according to your mood.

</div>

Our recommendation:

- Notation in the form of PAM (Purpose, Advantage, Metric).

Alternative forms of notation:

- Product case

- News from the Future

- Product Canvas

- Value Proposition

There is only one thing you should never do: Work without explicit goals or visions.

</div>

Goal definitions according to PAM:

Goal 1:

Advantage 1:

Metric 1:

Goal 2:

Advantage 2:

Metric 2:

Goal 3:

Advantage 3:

Metric 3:

# Stakeholder {#section-stakeholder}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

A (prioritized) list of your stakeholders, along with indications of where these stakeholders can help (or hinder) the analysis work.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Stakeholders are the most important sources for requirements. Therefore, you should know and document them. You need to know who can help you with what or hinder you in what way. You need to know who has what influence - and if opinions differ, you need to mediate or decide. Without explicitly identified stakeholders, all this is difficult.

</div>

<div markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

- Tables or lists (simple form)

- Possibly stakeholder map (more complex form)

</div>

Below we have included a simple stakeholder list as an example.

The order "role before person" has been chosen deliberately. This order has proven itself since requirements normally always represent needs from the perspective of a role, but the person taking on the role can change during the project.

If required, you can also add further columns (contact data, …​) - but consider the effort for their maintenance.

</div>

| Role             | Person             | Topic             | Influence             |
|---------------|----------------------------|---------------|---------------|
| *&lt;Role-1&gt;* | *&lt;Person-1&gt;* | *&lt;Topic-1&gt;* | \_&lt;Influence-1&gt; |
| *&lt;Role-2&gt;* | *&lt;Person-2&gt;* | *&lt;Topic-2&gt;* | \_&lt;Influence-2&gt; |
|                  |                    |                   |                       |

# Scope {#section-scope}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

Your product with all external interfaces to (human and automated) neighbors, resp. neighboring systems.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Scope is the area that you can influence. The environment of the product, to which there are certainly many interfaces, represents the context. The context cannot (usually) be decided by you alone, but can often be negotiated. To gain clarity it is important to describe both as much as possible and especially to define the boundary between the two scopes.

</div>

req42 recommends that you start with the business scope and do not limit the product scope too early. The decision about the product scope should be a conscious one. Read more about this indispensable topic in the blog post "Scope is not equal to Scope" or in \[2\]. In our courses, you will practice scope delimitation using a realistic case study.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

There are many different means of expression for representing scope delineation, but a good scope delineation makes the interfaces to the context explicit (e.g., in terms of inputs and outputs, of services provided and required, …​).

</div>

- Various forms of context diagrams

- Context chart

</div>

Insert [???] or [???][1] here.

Optional: add table with explanations of interfaces:

| Interface Name | Meaning/Explanation |
|----------------|---------------------|
| *&lt;IF-1&gt;* | *&lt;Meaning-1&gt;* |
| *&lt;IF-2&gt;* | *&lt;Meaning-2&gt;* |
|                |                     |

# Product Backlog {#section-product-backlog}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

An ordered list of product backlog items (at different levels of granularity: e.g. epics, features and user stories). Backlog items should be prioritized (better term: ranked) among each other.

</div>

The items with the greatest added value in terms of implementation effort should be at the top of the backlog to be implemented next.

You have to define explicitly what added value means for you and your development. The simplest definition is the business added value for the customer when implementing the requirement.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

The Scrum Guide defines:

</div>

"The Product Backlog is an ordered list of everything that is known to be included in the product. It serves as the single source of requirements for all changes to the product. The Product Owner is responsible for the Product Backlog, its contents, access to it, and the order of entries. A Product Backlog is never complete. During its initial development steps, it identifies the requirements that are initially known and best understood. The Product Backlog evolves with the product and its use. It is dynamic; it constantly adapts to make clear for the product what it needs to be adequate to its task, to compete, and to provide the required benefits."

As long as a product exists, so does its Product Backlog. So you see: the Product Backlog is really important for successful work as a Product Owner. But please fill in the other artifacts as well. Your job may not start with the Product Backlog and it certainly doesn’t end with the Product Backlog.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

Proven (regardless of granularity) for epics, features and user stories is the formula:

</div>

    As <role>.


0. [Business Goals](01_business-goals.md)

0. [Stakeholder](02_stakeholder.md)

0. [Scope](03_scope.md)

0. [Product Backlog](04_product-backlog.md)

0. [Supporting Models](05_supporting-models.md)

0. [Quality Requirements](06_quality-requirements.md)

0. [Constraints](07_constraints.md)

0. [Domain Terminology](08_domain-terminology.md)

0. [Assets](09_assets.md)

0. [Teams](10_teams.md)

0. [Roadmap](11_roadmap.md)

0. [Risks & Assumptions](12_risks-assumptions.md)

0. [](about-req42.md)
