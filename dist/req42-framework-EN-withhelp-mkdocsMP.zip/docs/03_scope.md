# Scope {#section-scope}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

Your product with all external interfaces to (human and automated) neighbors, resp. neighboring systems.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

Scope is the area that you can influence. The environment of the product, to which there are certainly many interfaces, represents the context. The context cannot (usually) be decided by you alone, but can often be negotiated. To gain clarity it is important to describe both as much as possible and especially to define the boundary between the two scopes.

</div>

req42 recommends that you start with the business scope and do not limit the product scope too early. The decision about the product scope should be a conscious one. Read more about this indispensable topic in the blog post "Scope is not equal to Scope" or in \[2\]. In our courses, you will practice scope delimitation using a realistic case study.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

There are many different means of expression for representing scope delineation, but a good scope delineation makes the interfaces to the context explicit (e.g., in terms of inputs and outputs, of services provided and required, …​).

</div>

- Various forms of context diagrams

- Context chart

</div>

Insert [???] or [???][1] here.

Optional: add table with explanations of interfaces:

| Interface Name | Meaning/Explanation |
|----------------|---------------------|
| *&lt;IF-1&gt;* | *&lt;Meaning-1&gt;* |
| *&lt;IF-2&gt;* | *&lt;Meaning-2&gt;* |
|                |                     |

  [Scope]: #section-scope {#toc-section-scope}
  [???]: #Context diagram
  [1]: #Context table
