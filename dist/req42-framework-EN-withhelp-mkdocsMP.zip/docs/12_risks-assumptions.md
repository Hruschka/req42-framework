# Risks & Assumptions {#section-risks-assumptions}

<div class="sidebar" markdown="1">

<div class="title" markdown="1">

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Content

</div>

(Prioritized) lists of risks you have identified and a list of assumptions you have made as a basis for decisions.

</div>

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Motivation

</div>

"Risk management is project management for adults" says Tim Lister of the Atlantic Systems Guild".

</div>

With this in mind, you should keep your risks under control as a product owner.

req42 provides you with the means to consciously manage risks. Especially when prioritizing your requirements you should balance business value and risk reduction.

<div class="formalpara" markdown="1">

<div class="title" markdown="1">

Notations/Tools

</div>

Simple tables or lists are often already sufficient.

</div>

</div>

## Risks {#_risks}

| Id  | Text | Probability | Damage Amount | Possible Measures |
|-----|------|-------------|---------------|-------------------|
|     |      |             |               |                   |
|     |      |             |               |                   |

## Assumptions {#_assumptions}

| Id  | Text |
|-----|------|
|     |      |
|     |      |

  [Risks & Assumptions]: #section-risks-assumptions {#toc-section-risks-assumptions}
  [Risks]: #_risks {#toc-_risks}
  [Assumptions]: #_assumptions {#toc-_assumptions}
