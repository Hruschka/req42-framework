# Roadmap {#section-roadmap}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Content
:::

\"Delivery artifacts put on the timeline\" - who delivers what and when?
::::

:::: formalpara
::: title
Motivation
:::

Agile projects also need a plan. The more distant a goal is, the less
precise the plan can be. The closer, the more precise.
::::

An explicitly known roadmap enables all participants to coordinate with
each other and to think along with each other, and therefore to take
into account what is still to come in the medium term when making
short-term decisions.

If you only live from hand to mouth, you may unknowingly make short-term
decisions that are contrary to longer-term product success. In our
courses we show you how rough or fine a roadmap can, may or should be.

:::: formalpara
::: title
Notations/Tools
:::

Whatever you have in use as a planning tool or which allows you to
present, if possible on one page, an appropriate overview over a longer
period of time.
::::
::::::::::

*\< Insert your planning here\>*
