# Assets {#section-assets}

## Budget {#_budget}

(possibly structured according to roadmap or intermediate goals, or
divided into personnel budget, material budget, ...​)

## Time frame/final date {#_time_framefinal_date}

## Team members {#_team_members}

(simple enumeration of team members for small team. Or a link to complex
team structure in section 10).

## External resources {#_external_resources}
