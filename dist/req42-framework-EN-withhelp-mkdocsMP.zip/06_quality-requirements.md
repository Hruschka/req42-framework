# Quality Requirements {#section-quality-requirements}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Content
:::

Quality requirements are the \"how\" to the \"what\" - qualitative
definitions or precisions of the functional requirements.
::::

:::: formalpara
::: title
Motivation
:::

Our experience shows: Quality requirements are (unfortunately) still
severely underestimated, not only in the agile world. Everyone wants
good quality products and services, but only a few make it explicit what
exactly is meant by this.
::::

Some quality requirements (such as response times) can perhaps be
integrated directly into a story (or added as an acceptance criterion).
However, the vast majority of quality requirements relate to many, if
not all, of the functional requirements in the product backlog.

Therefore, as a product owner, you need somewhere to specify and assign
the desired qualities of your products and services. For this activity,
industry-proven checklists (such as ISO 25010 and others) are available
to help you quickly identify and manage the most important categories.

:::: formalpara
::: title
Notations/Tools
:::

Simple textual scenarios, possibly structured according to the sections
of Q42, or the ISO 25010 quality tree, or according to VOLERE.
::::
::::::::::

*\< quality requirement or scenario 1\>* : *\<Link to functional
requirements or scope for this quality \>*

*\< quality requirement or scenario 2\>* : *\<Link to functional
requirements or scope for this quality \>*

*\< quality requirement or scenario 3\>* : *\<Link to functional
requirements or scope for this quality \>*

    .
    .
    .

*\< quality requirement or scenario n\>* : *\<Link to functional
requirements or scope for this quality \>*
