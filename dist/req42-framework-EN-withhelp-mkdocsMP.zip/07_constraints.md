# Constraints {#section-constraints}

## Organizational Constraints {#_organizational_constraints}

-   *\<OrgConstraint1\>*

-   *\<OrgConstraint2\>*

-   *\<OrgContraint3\>*

## Technical Constraints {#_technical_constraints}

-   *\<TechConstraint1\>*

-   *\<TechConstraint2\>*

-   *\<TechContraint3\>*
