# Constraints {#section-constraints}

:::::::::: sidebar
::: title
:::

:::: formalpara
::: title
Content
:::

Technological or organizational (mandated) constraints for the
development process, such as mandatory activities, prescribed documents
and their content, milestones to be met, ...​
::::

:::: formalpara
::: title
Motivation
:::

Such constraints are also requirements. And since they often apply to
several or even all functional requirements, they are difficult to
accommodate in the ordered product backlog. Just make sure that all
stakeholders know these constraints and have access to them when needed.
::::

:::: formalpara
::: title
Form
:::

Simple lists, possibly organized by category.
::::
::::::::::

## Organizational Constraints {#_organizational_constraints}

- *\<OrgConstraint1\>*

- *\<OrgConstraint2\>*

- *\<OrgContraint3\>*

## Technical Constraints {#_technical_constraints}

- *\<TechConstraint1\>*

- *\<TechConstraint2\>*

- *\<TechContraint3\>*
