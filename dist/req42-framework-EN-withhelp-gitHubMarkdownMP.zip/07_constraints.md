# Constraints

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Content

</div>

Technological or organizational (mandated) constraints for the
development process, such as mandatory activities, prescribed documents
and their content, milestones to be met, …​

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Such constraints are also requirements. And since they often apply to
several or even all functional requirements, they are difficult to
accommodate in the ordered product backlog. Just make sure that all
stakeholders know these constraints and have access to them when needed.

</div>

<div class="formalpara">

<div class="title">

Form

</div>

Simple lists, possibly organized by category.

</div>

</div>

## Organizational Constraints

- *\<OrgConstraint1\>*

- *\<OrgConstraint2\>*

- *\<OrgContraint3\>*

## Technical Constraints

- *\<TechConstraint1\>*

- *\<TechConstraint2\>*

- *\<TechContraint3\>*
