# Scope

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Content

</div>

Your product with all external interfaces to (human and automated)
neighbors, resp. neighboring systems.

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Scope is the area that you can influence. The environment of the
product, to which there are certainly many interfaces, represents the
context. The context cannot (usually) be decided by you alone, but can
often be negotiated. To gain clarity it is important to describe both as
much as possible and especially to define the boundary between the two
scopes.

</div>

req42 recommends that you start with the business scope and do not limit
the product scope too early. The decision about the product scope should
be a conscious one. Read more about this indispensable topic in the blog
post "Scope is not equal to Scope" or in \[2\]. In our courses, you will
practice scope delimitation using a realistic case study.

<div class="formalpara">

<div class="title">

Notations/Tools

</div>

There are many different means of expression for representing scope
delineation, but a good scope delineation makes the interfaces to the
context explicit (e.g., in terms of inputs and outputs, of services
provided and required, …​).

</div>

- Various forms of context diagrams

- Context chart

</div>

Insert *\<Context diagram\>* or *\<Context table\>* here.

Optional: add table with explanations of interfaces:

| Interface Name | Meaning/Explanation |
|----------------|---------------------|
| *\<IF-1\>*     | *\<Meaning-1\>*     |
| *\<IF-2\>*     | *\<Meaning-2\>*     |
|                |                     |
