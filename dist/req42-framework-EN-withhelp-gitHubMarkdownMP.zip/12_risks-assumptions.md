# Risks & Assumptions

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Content

</div>

(Prioritized) lists of risks you have identified and a list of
assumptions you have made as a basis for decisions.

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

"Risk management is project management for adults" says Tim Lister of
the Atlantic Systems Guild".

</div>

With this in mind, you should keep your risks under control as a product
owner.

req42 provides you with the means to consciously manage risks.
Especially when prioritizing your requirements you should balance
business value and risk reduction.

<div class="formalpara">

<div class="title">

Notations/Tools

</div>

Simple tables or lists are often already sufficient.

</div>

</div>

## Risks

| Id  | Text | Probability | Damage Amount | Possible Measures |
|-----|------|-------------|---------------|-------------------|
|     |      |             |               |                   |
|     |      |             |               |                   |

## Assumptions

| Id  | Text |
|-----|------|
|     |      |
|     |      |
