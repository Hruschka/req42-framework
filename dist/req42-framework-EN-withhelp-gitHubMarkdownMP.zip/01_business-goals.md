# Business Goals

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Content

</div>

The business objectives of your product development or project. Short
and concise, understandable and transparent for your stakeholders.

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Goals must be specified and agreed upon to the point where everyone
involved has a clear idea of what is to be accomplished and in what time
frames. Establishing vision and goals guides the team in developing
detailed requirements and avoids fragmentation.

</div>

Perhaps your clients gave you rough goals or a vision when they
entrusted you with the role of product owner. Often, however, the
precision of these specifications is not enough to lead a team
systematically to success.

<div class="formalpara">

<div class="title">

Notations/Tools

</div>

A wide variety of means of expression are available for defining goals,
which you can choose according to your mood.

</div>

Our recommendation:

- Notation in the form of PAM (Purpose, Advantage, Metric).

Alternative forms of notation:

- Product case

- News from the Future

- Product Canvas

- Value Proposition

There is only one thing you should never do: Work without explicit goals
or visions.

</div>

Goal definitions according to PAM:

Goal 1:

Advantage 1:

Metric 1:

Goal 2:

Advantage 2:

Metric 2:

Goal 3:

Advantage 3:

Metric 3:
