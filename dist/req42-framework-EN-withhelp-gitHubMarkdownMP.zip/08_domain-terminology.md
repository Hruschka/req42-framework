# Domain Terminology

<div class="formalpara-title">

**Content**

</div>

A glossary of technical terms with definitions.

<div class="formalpara-title">

**Motivation**

</div>

Terms from your domain appear in every epic, feature, or story. These
terms should be clear to everyone involved. And that’s why it is
desirable to have a glossary of such terms for a project or product
development. Make sure that everyone involved speaks a common language -
and has access to agreed-upon definitions of terms instead of bringing
new words into play in every meeting.

<div class="formalpara-title">

**Notations/Tools**

</div>

Alphabetically ordered list of term definitions

Siehe [Querschnittliche Konzepte](https://docs.arc42.org/section-8/) in
der online-Dokumentation (auf Englisch).

| Term        | Definition        |
|-------------|-------------------|
| *\<Term-1>* | *\<Definition-1>* |
| *\<Term-2>* | *\<Defintion-2>*  |
|             |                   |
