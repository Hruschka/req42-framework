# Domain Terminology

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Content

</div>

A glossary of technical terms with definitions. The "ubiquitous
language" of your domain

</div>

<div class="formalpara">

<div class="title">

Motivation

</div>

Terms from your domain appear in every epic, feature, or story. These
terms should be clear to everyone involved. And that’s why it is
desirable to have a glossary of such terms for a project or product
development.

</div>

Make sure that everyone involved speaks a common language - and has
access to agreed-upon definitions of terms instead of bringing new words
into play in every meeting.

<div class="formalpara">

<div class="title">

Notations/Tools

</div>

Alphabetically ordered list of term definitions

</div>

</div>

| Term         | Definition         |
|--------------|--------------------|
| *\<Term-1\>* | *\<Definition-1\>* |
| *\<Term-2\>* | *\<Definition-2\>* |
|              |                    |
