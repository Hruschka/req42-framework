# Supporting Models

<div class="formalpara-title">

**Content**

</div>

Any kind of graphical models that facilitate the understanding (of
relationships) of Backlog Items. The diagrams should be linked to items
from the Product Backlog.

<div class="formalpara-title">

**Motivation**

</div>

In the agile world, it has become widespread to write requirements in
the form of epics, features or user stories on little cards or to file
them in equivalent form in tools.

Nevertheless, communication among all stakeholders sometimes becomes
much easier if you also use the tools we have come to know over the last
decades to make the colloquial language more precise. So don’t be afraid
to use models if they help communication.

Don’t worry: these models don’t have to be perfect. But especially with
increasing complexity (loops or case distinctions), a graphical
visualization of the steps of a business process promotes understanding
better than many tickets in the system without recognizable sequences
and dependencies.

-   Flowcharts

-   activity diagrams

-   BPMN

-   state models

-   data models

-   UI prototypes

-   mock-ups

-   wireframes

Simple modeling tools like Gliffy, Diagrams.Net (formerly DrawIO), ……,
or DSLs like PlantUML, Kroki, … or UML modeling tools like Enterprise
Architect, Visual Paradigm, MagicDraw are suitable for creating the
models. The models should be linked to your backlog items (in both
directions)

Siehe [Bausteinsicht](https://docs.arc42.org/section-5/) in der
online-Dokumentation (auf Englisch!).

[???](#Diagram Title 1:). [???](#insert diagram and explanations here)
[Features or Stories](#optional: Link to Epics)
[???](#Diagram Title 12). [???](#insert diagram and explanations here)
[Features or Stories](#optional: Link to Epics)
[???](#Diagram Title 3:). [???](#insert diagram and explanations here)
[Features or Stories](#optional: Link to Epics) ….
[???](#Diagram Title n:). [???](#insert diagram and explanations here)
[Features or Stories](#optional: Link to Epics)
