# Teams

<div class="sidebar">

<div class="title">

</div>

<div class="formalpara">

<div class="title">

Content

</div>

This section can be omitted for small product developments with only one
development team, since the team members are already listed in the
previous section.

</div>

For scaled large products, the organization chart of your teams should
be here and an assignment to the topics (e.g. epics, features, …​) this
team is responsible for.

<div class="formalpara">

<div class="title">

Motivation

</div>

If you have more than one team at your disposal, it goes without saying
that you should have an overview of who works in which (sub-)team and
how these teams are organized.

</div>

The focus should be on (sub-)teams being organized in such a way that
they can deliver functions/features or partial products as independently
as possible without having to constantly coordinate with everyone else.

<div class="formalpara">

<div class="title">

Notations/Tools

</div>

Lists of teams (each with assigned people and assigned topics from the
roadmap or from the product backlog (e.g., epics or features).

</div>

</div>

| Team         | Team Members        | Feature         |
|--------------|---------------------|-----------------|
| *\<Team-1\>* | PO: *\<Person-1\>*  | *\<Feature-A\>* |
|              | *\<Team member-2\>* |                 |
|              | *\<Team member-3\>* |                 |
|              |                     |                 |
| *\<Team-2\>* | PO: *\<Person-2\>*  | *\<Feature-B\>* |
|              | *\<Team member-2\>* |                 |
|              |                     |                 |
